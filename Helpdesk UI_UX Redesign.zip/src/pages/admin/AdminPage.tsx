import { useState } from 'react';
import { useLocation } from 'react-router-dom';
import {
  Users, Plus, Search, Edit2, RotateCcw, ToggleLeft, ToggleRight,
  CheckCircle2, XCircle, RefreshCw, Database, HardDrive, Clock,
  BarChart3, TrendingUp, Download, BarChart2, Layers,
  Save, AlertTriangle
} from 'lucide-react';
import { RoleBadge } from '../../components/ui/Badge';
import { staffUsers } from '../../data/mock';

// ─── User Management ───────────────────────────────────────────────────────────
function UsersPanel() {
  const [users, setUsers] = useState(staffUsers);
  const [search, setSearch] = useState('');
  const [filterRole, setFilterRole] = useState('all');

  const filtered = users.filter((u) => {
    if (filterRole !== 'all' && u.role !== filterRole) return false;
    if (search && !u.name.toLowerCase().includes(search.toLowerCase()) && !u.email.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-[22px] font-bold text-[#0F172A]">Manajemen User & Staf</h2>
          <p className="text-[14px] text-[#64748B] mt-0.5">Kelola operator, teknisi, dan admin sistem</p>
        </div>
        <button className="flex items-center gap-2 h-10 px-4 rounded-[10px] bg-[#0D5C75] text-white text-[14px] font-semibold hover:bg-[#083342] transition-colors shadow-sm">
          <Plus size={16} /> Tambah User
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari nama atau email..." className="w-full h-9 pl-9 pr-4 rounded-[10px] border border-[#E2E8F0] text-[13px] text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#199FB1]/30 transition-all" />
        </div>
        <select value={filterRole} onChange={(e) => setFilterRole(e.target.value)} className="h-9 pl-3 pr-8 rounded-[10px] border border-[#E2E8F0] text-[13px] bg-white focus:outline-none focus:ring-2 focus:ring-[#199FB1]/30">
          <option value="all">Semua Role</option>
          <option value="admin">Admin</option>
          <option value="operator">Operator</option>
          <option value="teknisi">Teknisi</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#E2E8F0] bg-[#F8FAFC]">
              {['User', 'Role', 'Unit Kerja', 'Tiket Aktif', 'Status', 'Aksi'].map((h) => (
                <th key={h} className="px-4 py-3 text-left text-[12px] font-semibold text-[#64748B]">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((user) => (
              <tr key={user.id} className="border-b border-[#E2E8F0]/60 hover:bg-[#EAF4F8]/30 transition-colors">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center text-[13px] font-bold text-white flex-shrink-0 ${user.active ? 'bg-[#0D5C75]' : 'bg-[#CBD5E1]'}`}>
                      {user.avatarInitials}
                    </div>
                    <div>
                      <p className="text-[14px] font-semibold text-[#0F172A]">{user.name}</p>
                      <p className="text-[12px] text-[#64748B]">{user.email}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3"><RoleBadge role={user.role} /></td>
                <td className="px-4 py-3 text-[13px] text-[#64748B]">{user.unit}</td>
                <td className="px-4 py-3">
                  <span className={`text-[13px] font-semibold ${user.activeTickets > 4 ? 'text-[#DC2626]' : user.activeTickets > 2 ? 'text-[#D97706]' : 'text-[#059669]'}`}>{user.activeTickets}</span>
                </td>
                <td className="px-4 py-3">
                  <button onClick={() => setUsers((prev) => prev.map((u) => u.id === user.id ? { ...u, active: !u.active } : u))}>
                    {user.active
                      ? <div className="flex items-center gap-1.5 text-[#10B981]"><ToggleRight size={20} /><span className="text-[12px] font-semibold">Aktif</span></div>
                      : <div className="flex items-center gap-1.5 text-[#94A3B8]"><ToggleLeft size={20} /><span className="text-[12px] font-semibold">Nonaktif</span></div>
                    }
                  </button>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1">
                    <button className="p-1.5 rounded-[6px] text-[#64748B] hover:text-[#0D5C75] hover:bg-[#EAF4F8] transition-all" title="Edit"><Edit2 size={14} /></button>
                    <button className="p-1.5 rounded-[6px] text-[#64748B] hover:text-[#F59E0B] hover:bg-[#FFFBEB] transition-all" title="Reset Password"><RotateCcw size={14} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Datasource ─────────────────────────────────────────────────────────────────
function DatasourcePanel() {
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<'ok' | 'error' | null>(null);

  const handleTest = async () => {
    setTesting(true); setTestResult(null);
    await new Promise((r) => setTimeout(r, 1500));
    setTesting(false); setTestResult('ok');
  };

  return (
    <div className="p-6 space-y-5">
      <div>
        <h2 className="text-[22px] font-bold text-[#0F172A]">Integrasi Data & Google Workspace</h2>
        <p className="text-[14px] text-[#64748B] mt-0.5">Status koneksi ke backend Google Apps Script dan Google Sheets</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* GAS API status */}
        <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-[10px] bg-[#EAF4F8] flex items-center justify-center"><Database size={18} color="#0D5C75" /></div>
              <div>
                <h3 className="text-[15px] font-bold text-[#0F172A]">Google Apps Script API</h3>
                <p className="text-[12px] text-[#64748B]">Endpoint backend utama</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#ECFDF5] border border-[#A7F3D0]">
              <div className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
              <span className="text-[11px] font-semibold text-[#059669]">Terhubung</span>
            </div>
          </div>
          <div className="space-y-2 text-[13px]">
            {[
              { label: 'URL Endpoint', value: 'https://script.google.com/macros/s/AKfy...', mono: true },
              { label: 'Ping Terakhir', value: '1 menit lalu', mono: false },
              { label: 'Response Time', value: '247ms', mono: true },
            ].map(({ label, value, mono }) => (
              <div key={label} className="flex items-center gap-3">
                <span className="text-[#64748B] w-28 flex-shrink-0">{label}</span>
                <span className={`${mono ? 'font-mono' : ''} text-[#0F172A] truncate`}>{value}</span>
              </div>
            ))}
          </div>
          <button
            onClick={handleTest}
            disabled={testing}
            className="mt-4 flex items-center gap-2 h-9 px-4 rounded-[10px] border border-[#E2E8F0] text-[13px] font-semibold text-[#64748B] hover:bg-[#F1F5F9] disabled:opacity-60 transition-all"
          >
            {testing ? <RefreshCw size={14} className="animate-spin" /> : <RefreshCw size={14} />}
            {testing ? 'Mengecek...' : 'Test Koneksi'}
          </button>
          {testResult === 'ok' && (
            <div className="flex items-center gap-2 mt-3 text-[12px] text-[#059669]"><CheckCircle2 size={14} /> Koneksi berhasil — respons 231ms</div>
          )}
          {testResult === 'error' && (
            <div className="flex items-center gap-2 mt-3 text-[12px] text-[#DC2626]"><XCircle size={14} /> Gagal terhubung — timeout</div>
          )}
        </div>

        {/* Google Sheets sync */}
        <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-[10px] bg-[#F0FDF4] flex items-center justify-center"><Layers size={18} color="#059669" /></div>
              <div>
                <h3 className="text-[15px] font-bold text-[#0F172A]">Google Sheets</h3>
                <p className="text-[12px] text-[#64748B]">Data store tiket & laporan</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#ECFDF5] border border-[#A7F3D0]">
              <div className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
              <span className="text-[11px] font-semibold text-[#059669]">Sinkron</span>
            </div>
          </div>
          <div className="space-y-2 text-[13px] mb-4">
            <div className="flex items-center gap-3"><span className="text-[#64748B] w-28 flex-shrink-0">Sinkron Terakhir</span><span className="text-[#0F172A]">5 menit lalu</span></div>
            <div className="flex items-center gap-3"><span className="text-[#64748B] w-28 flex-shrink-0">Total Baris</span><span className="font-mono text-[#0F172A]">1,842</span></div>
          </div>
          <button className="flex items-center gap-2 h-9 px-4 rounded-[10px] bg-[#0D5C75] text-white text-[13px] font-semibold hover:bg-[#083342] transition-colors">
            <RefreshCw size={14} /> Sinkronkan Sekarang
          </button>
        </div>

        {/* Drive storage */}
        <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm p-5 lg:col-span-2">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-[10px] bg-[#FFF7ED] flex items-center justify-center"><HardDrive size={18} color="#D97706" /></div>
            <div>
              <h3 className="text-[15px] font-bold text-[#0F172A]">Google Drive — Storage Lampiran</h3>
              <p className="text-[12px] text-[#64748B]">Folder penyimpanan file tiket</p>
            </div>
          </div>
          <div className="mb-2 flex items-center justify-between">
            <span className="text-[13px] text-[#64748B]">7.4 GB dari 15 GB terpakai</span>
            <span className="text-[13px] font-semibold text-[#D97706]">49%</span>
          </div>
          <div className="h-2.5 bg-[#E2E8F0] rounded-full overflow-hidden">
            <div className="h-full rounded-full bg-gradient-to-r from-[#F59E0B] to-[#F58A61]" style={{ width: '49%' }} />
          </div>
          <p className="text-[12px] text-[#94A3B8] mt-2">7.6 GB tersisa · Peringatan akan muncul jika &gt; 80%</p>
        </div>
      </div>
    </div>
  );
}

// ─── SLA Settings ───────────────────────────────────────────────────────────────
function SlaSettingsPanel() {
  const slaMatrix = [
    { category: 'Jaringan & Internet', low: 72, medium: 24, high: 8, urgent: 2 },
    { category: 'Sistem Informasi & Aplikasi', low: 72, medium: 24, high: 8, urgent: 2 },
    { category: 'Sarana & Prasarana', low: 72, medium: 24, high: 8, urgent: 4 },
    { category: 'Hardware & Komputer', low: 72, medium: 24, high: 8, urgent: 4 },
    { category: 'Layanan Akun', low: 72, medium: 24, high: 8, urgent: 2 },
    { category: 'Layanan Umum', low: 72, medium: 24, high: 24, urgent: 8 },
  ];

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-[22px] font-bold text-[#0F172A]">Pengaturan SLA & Notifikasi</h2>
          <p className="text-[14px] text-[#64748B] mt-0.5">Target waktu per kombinasi kategori dan prioritas (dalam jam)</p>
        </div>
        <button className="flex items-center gap-2 h-10 px-4 rounded-[10px] bg-[#0D5C75] text-white text-[14px] font-semibold hover:bg-[#083342] transition-colors shadow-sm">
          <Save size={15} /> Simpan Perubahan
        </button>
      </div>

      <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#E2E8F0] bg-[#F8FAFC]">
              <th className="px-4 py-3 text-left text-[12px] font-semibold text-[#64748B]">Kategori</th>
              {['Rendah', 'Sedang', 'Tinggi', 'Urgent'].map((p) => (
                <th key={p} className="px-4 py-3 text-left text-[12px] font-semibold text-[#64748B]">{p}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {slaMatrix.map((row) => (
              <tr key={row.category} className="border-b border-[#E2E8F0]/60">
                <td className="px-4 py-3 text-[13px] font-medium text-[#0F172A]">{row.category}</td>
                {[row.low, row.medium, row.high, row.urgent].map((val, i) => (
                  <td key={i} className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        defaultValue={val}
                        className="w-16 h-8 px-2 rounded-[6px] border border-[#E2E8F0] text-[13px] font-mono text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#199FB1]/30 focus:border-[#199FB1] text-center"
                      />
                      <span className="text-[11px] text-[#94A3B8]">jam</span>
                    </div>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-start gap-3 p-4 bg-[#FFFBEB] rounded-[12px] border border-[#FDE68A]">
        <AlertTriangle size={16} className="text-[#D97706] mt-0.5 flex-shrink-0" />
        <p className="text-[13px] text-[#92400E]">Perubahan SLA hanya berlaku untuk tiket baru. Tiket yang sudah berjalan tetap menggunakan SLA saat dibuat.</p>
      </div>
    </div>
  );
}

// ─── Reports ────────────────────────────────────────────────────────────────────
function ReportsPanel() {
  const barData = [
    { label: 'Jaringan', value: 42, color: '#0284C7' },
    { label: 'Sarpras', value: 28, color: '#059669' },
    { label: 'Hardware', value: 35, color: '#D97706' },
    { label: 'Akun', value: 20, color: '#7C3AED' },
    { label: 'Sysinfo', value: 18, color: '#8B5CF6' },
    { label: 'Umum', value: 12, color: '#64748B' },
  ];
  const maxBar = Math.max(...barData.map((d) => d.value));

  const donutData = [
    { label: 'Selesai', value: 284, color: '#10B981' },
    { label: 'In Progress', value: 42, color: '#8B5CF6' },
    { label: 'Open', value: 28, color: '#0284C7' },
    { label: 'Menunggu', value: 15, color: '#F59E0B' },
  ];
  const total = donutData.reduce((s, d) => s + d.value, 0);

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-[22px] font-bold text-[#0F172A]">Laporan & Analytics</h2>
          <p className="text-[14px] text-[#64748B] mt-0.5">Ringkasan performa helpdesk bulan September 2024</p>
        </div>
        <button className="flex items-center gap-2 h-10 px-4 rounded-[10px] border border-[#E2E8F0] text-[14px] font-semibold text-[#64748B] bg-white hover:bg-[#F1F5F9] transition-colors">
          <Download size={15} /> Export PDF
        </button>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total Tiket', value: '369', icon: BarChart2, color: '#0D5C75', bg: '#EAF4F8' },
          { label: 'Tingkat Resolusi', value: '94%', icon: TrendingUp, color: '#10B981', bg: '#ECFDF5' },
          { label: 'Rata-rata SLA', value: '18.6j', icon: Clock, color: '#8B5CF6', bg: '#F5F3FF' },
          { label: 'Tiket Lewat SLA', value: '23', icon: AlertTriangle, color: '#EF4444', bg: '#FEF2F2' },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <div key={label} className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm p-4">
            <div className="w-9 h-9 rounded-[10px] flex items-center justify-center mb-3" style={{ backgroundColor: bg }}>
              <Icon size={16} style={{ color }} />
            </div>
            <p className="text-[24px] font-bold text-[#0F172A]">{value}</p>
            <p className="text-[12px] text-[#64748B] mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Volume per kategori bar chart */}
        <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 size={16} className="text-[#64748B]" />
            <h3 className="text-[15px] font-bold text-[#0F172A]">Volume per Kategori</h3>
          </div>
          <div className="space-y-2.5">
            {barData.map(({ label, value, color }) => (
              <div key={label} className="flex items-center gap-3">
                <span className="text-[12px] text-[#64748B] w-16 flex-shrink-0">{label}</span>
                <div className="flex-1 h-6 bg-[#F1F5F9] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full flex items-center justify-end pr-2 transition-all duration-500"
                    style={{ width: `${(value / maxBar) * 100}%`, backgroundColor: color }}
                  >
                    <span className="text-[11px] font-bold text-white">{value}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Distribusi status donut */}
        <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-4">
            <Layers size={16} className="text-[#64748B]" />
            <h3 className="text-[15px] font-bold text-[#0F172A]">Distribusi Status</h3>
          </div>
          <div className="flex items-center gap-6">
            {/* Simple visual donut-like ring */}
            <div className="relative w-28 h-28 flex-shrink-0">
              <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                {(() => {
                  let offset = 0;
                  return donutData.map(({ value, color, label }) => {
                    const pct = value / total;
                    const len = pct * 251.2;
                    const el = (
                      <circle
                        key={label}
                        cx="50" cy="50" r="40"
                        fill="none"
                        stroke={color}
                        strokeWidth="18"
                        strokeDasharray={`${len} ${251.2 - len}`}
                        strokeDashoffset={-offset}
                      />
                    );
                    offset += len;
                    return el;
                  });
                })()}
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-[20px] font-bold text-[#0F172A]">{total}</span>
                <span className="text-[10px] text-[#64748B]">total</span>
              </div>
            </div>
            <div className="space-y-2 flex-1">
              {donutData.map(({ label, value, color }) => (
                <div key={label} className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: color }} />
                    <span className="text-[13px] text-[#64748B]">{label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[13px] font-bold text-[#0F172A]">{value}</span>
                    <span className="text-[11px] text-[#94A3B8]">{Math.round(value / total * 100)}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Teknisi leaderboard */}
        <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm p-5 lg:col-span-2">
          <h3 className="text-[15px] font-bold text-[#0F172A] mb-4">Performa Teknisi — Tiket Diselesaikan Bulan Ini</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              { name: 'Budi Santoso', unit: 'UPT TI', resolved: 48, avg: '14.2j', initials: 'BS' },
              { name: 'Siti Nurhayati', unit: 'UPT TI', resolved: 38, avg: '11.8j', initials: 'SN' },
              { name: 'Ahmad Fauzi', unit: 'UPT Sarpras', resolved: 32, avg: '22.4j', initials: 'AF' },
              { name: 'Dewi Rahayu', unit: 'UPT TI', resolved: 29, avg: '16.1j', initials: 'DR' },
            ].map((tech, i) => (
              <div key={tech.name} className="flex items-center gap-3 p-3 rounded-[10px] border border-[#E2E8F0] hover:bg-[#EAF4F8]/30 transition-colors">
                <span className="text-[16px] font-bold text-[#CBD5E1] w-6 text-center flex-shrink-0">#{i + 1}</span>
                <div className="w-9 h-9 rounded-full bg-[#0D5C75] flex items-center justify-center text-[12px] font-bold text-white flex-shrink-0">{tech.initials}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-[14px] font-semibold text-[#0F172A]">{tech.name}</p>
                  <p className="text-[12px] text-[#64748B]">{tech.unit}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-[16px] font-bold text-[#0D5C75]">{tech.resolved}</p>
                  <p className="text-[11px] text-[#94A3B8]">Ø {tech.avg}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main ───────────────────────────────────────────────────────────────────────
export default function AdminPage() {
  const location = useLocation();
  const path = location.pathname;

  if (path.includes('/users')) return <UsersPanel />;
  if (path.includes('/datasource')) return <DatasourcePanel />;
  if (path.includes('/settings')) return <SlaSettingsPanel />;
  if (path.includes('/reports')) return <ReportsPanel />;
  return <UsersPanel />;
}
