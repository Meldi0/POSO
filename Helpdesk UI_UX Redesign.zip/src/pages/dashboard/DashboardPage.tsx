import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { LayoutGrid, TableIcon, Calendar, Filter, Plus, Download, RefreshCw } from 'lucide-react';
import KanbanBoard from '../../components/features/KanbanBoard';
import TicketTable from '../../components/features/TicketTable';
import TicketDrawer from '../../components/features/TicketDrawer';
import { mockTickets as initialTickets, categoryMeta } from '../../data/mock';
import { useToast } from '../../components/ui/Toast';
import type { Ticket, TicketStatus, ServiceCategory } from '../../data/types';

type ViewMode = 'kanban' | 'table';

const statusLabels: Record<TicketStatus, string> = {
  open: 'Open', in_progress: 'In Progress', waiting: 'Menunggu', closed: 'Selesai',
};

export default function DashboardPage() {
  const [view, setView] = useState<ViewMode>('kanban');
  const [tickets, setTickets] = useState<Ticket[]>(initialTickets);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [filterCategory, setFilterCategory] = useState<ServiceCategory | 'all'>('all');
  const [filterStatus, setFilterStatus] = useState<TicketStatus | 'all'>('all');
  const [loading] = useState(false);
  const [fabCollapsed, setFabCollapsed] = useState(false);
  const { toast } = useToast();
  const idleTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const resetIdle = () => {
      setFabCollapsed(true);
      if (idleTimer.current) clearTimeout(idleTimer.current);
      idleTimer.current = setTimeout(() => setFabCollapsed(false), 2000);
    };
    window.addEventListener('scroll', resetIdle, { passive: true });
    return () => {
      window.removeEventListener('scroll', resetIdle);
      if (idleTimer.current) clearTimeout(idleTimer.current);
    };
  }, []);

  const handleStatusChange = (ticket: Ticket, newStatus: TicketStatus) => {
    setTickets((prev) => prev.map((t) => t.id === ticket.id ? { ...t, status: newStatus, updatedAt: new Date().toISOString() } : t));
    if (selectedTicket?.id === ticket.id) {
      setSelectedTicket((prev) => prev ? { ...prev, status: newStatus } : null);
    }
    toast(`Tiket #${ticket.id} dipindah ke ${statusLabels[newStatus]}`, 'success');
  };

  const filteredTickets = tickets.filter((t) => {
    if (filterCategory !== 'all' && t.category !== filterCategory) return false;
    if (filterStatus !== 'all' && t.status !== filterStatus) return false;
    return true;
  });

  const stats = {
    open: tickets.filter((t) => t.status === 'open').length,
    in_progress: tickets.filter((t) => t.status === 'in_progress').length,
    waiting: tickets.filter((t) => t.status === 'waiting').length,
    closed: tickets.filter((t) => t.status === 'closed').length,
    urgent: tickets.filter((t) => t.priority === 'urgent' && t.status !== 'closed').length,
    breached: tickets.filter((t) => t.slaStatus === 'breached' && t.status !== 'closed').length,
  };

  return (
    <div className="flex flex-col h-full min-h-0 p-4 lg:p-6 gap-4">
      {/* Stats strip */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-3 flex-shrink-0">
        {[
          { label: 'Open', value: stats.open, color: '#0284C7', bg: '#EFF6FF' },
          { label: 'In Progress', value: stats.in_progress, color: '#8B5CF6', bg: '#F5F3FF' },
          { label: 'Menunggu', value: stats.waiting, color: '#F59E0B', bg: '#FFFBEB' },
          { label: 'Selesai Hari Ini', value: stats.closed, color: '#10B981', bg: '#ECFDF5' },
          { label: 'Urgent Aktif', value: stats.urgent, color: '#F58A61', bg: '#FFF7ED' },
          { label: 'Lewat SLA', value: stats.breached, color: '#EF4444', bg: '#FEF2F2' },
        ].map(({ label, value, color, bg }) => (
          <div
            key={label}
            className="rounded-[12px] border p-3 flex flex-col gap-0.5"
            style={{ backgroundColor: bg, borderColor: `${color}25` }}
          >
            <span className="text-[22px] font-bold leading-tight" style={{ color }}>{value}</span>
            <span className="text-[11px] font-medium text-[#64748B]">{label}</span>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3 flex-shrink-0">
        {/* View mode toggle */}
        <div className="flex items-center bg-white border border-[#E2E8F0] rounded-[10px] p-1 gap-1">
          <button
            onClick={() => setView('kanban')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-[8px] text-[13px] font-semibold transition-all ${view === 'kanban' ? 'bg-[#0D5C75] text-white shadow-sm' : 'text-[#64748B] hover:bg-[#F1F5F9]'}`}
          >
            <LayoutGrid size={14} /> Kanban
          </button>
          <button
            onClick={() => setView('table')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-[8px] text-[13px] font-semibold transition-all ${view === 'table' ? 'bg-[#0D5C75] text-white shadow-sm' : 'text-[#64748B] hover:bg-[#F1F5F9]'}`}
          >
            <TableIcon size={14} /> Tabel
          </button>
        </div>

        {/* Category filter */}
        <div className="flex items-center gap-2">
          <Filter size={14} className="text-[#94A3B8]" />
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value as ServiceCategory | 'all')}
            className="h-9 pl-3 pr-8 rounded-[10px] border border-[#E2E8F0] text-[13px] text-[#0F172A] bg-white focus:outline-none focus:ring-2 focus:ring-[#199FB1]/30 transition-all"
          >
            <option value="all">Semua Kategori</option>
            {Object.entries(categoryMeta).map(([k, m]) => (
              <option key={k} value={k}>{m.label}</option>
            ))}
          </select>
        </div>

        {/* Status filter */}
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value as TicketStatus | 'all')}
          className="h-9 pl-3 pr-8 rounded-[10px] border border-[#E2E8F0] text-[13px] text-[#0F172A] bg-white focus:outline-none focus:ring-2 focus:ring-[#199FB1]/30 transition-all"
        >
          <option value="all">Semua Status</option>
          <option value="open">Open</option>
          <option value="in_progress">In Progress</option>
          <option value="waiting">Menunggu</option>
          <option value="closed">Selesai</option>
        </select>

        {/* Date filter */}
        <button className="flex items-center gap-2 h-9 px-3 rounded-[10px] border border-[#E2E8F0] text-[13px] font-medium text-[#64748B] bg-white hover:bg-[#F1F5F9] transition-colors">
          <Calendar size={14} /> Hari ini
        </button>

        {/* Right actions */}
        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={() => toast('Data diperbarui', 'success')}
            className="flex items-center gap-2 h-9 px-3 rounded-[10px] border border-[#E2E8F0] text-[13px] font-medium text-[#64748B] bg-white hover:bg-[#F1F5F9] transition-colors"
          >
            <RefreshCw size={14} /> Sinkronkan
          </button>
          <button className="flex items-center gap-2 h-9 px-3 rounded-[10px] border border-[#E2E8F0] text-[13px] font-medium text-[#64748B] bg-white hover:bg-[#F1F5F9] transition-colors">
            <Download size={14} /> Export
          </button>
        </div>
      </div>

      {/* Board / Table area */}
      <div className="flex-1 min-h-0 overflow-hidden">
        {view === 'kanban' ? (
          <div className="h-full flex flex-col gap-4">
            <KanbanBoard
              tickets={filteredTickets}
              loading={loading}
              onTicketClick={setSelectedTicket}
              onStatusChange={handleStatusChange}
            />
          </div>
        ) : (
          <div className="h-full bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm overflow-hidden">
            <TicketTable
              tickets={filteredTickets}
              loading={loading}
              onTicketClick={setSelectedTicket}
              onStatusChange={handleStatusChange}
            />
          </div>
        )}
      </div>

      {/* Ticket Drawer */}
      <TicketDrawer
        ticket={selectedTicket}
        onClose={() => setSelectedTicket(null)}
        onStatusChange={handleStatusChange}
      />

      {/* FAB */}
      <motion.button
        layout
        transition={{ duration: 0.22, ease: [0.32, 0.72, 0, 1] }}
        className="fixed right-6 bottom-6 flex items-center gap-2 h-12 rounded-full bg-[#F58A61] text-white text-[14px] font-semibold shadow-xl hover:bg-[#E77448] hover:shadow-2xl transition-colors z-30 overflow-hidden"
        style={{ paddingLeft: fabCollapsed ? 14 : 20, paddingRight: fabCollapsed ? 14 : 20 }}
        onClick={() => toast('Membuka form tiket cepat...', 'info')}
        aria-label="Buat tiket baru"
      >
        <Plus size={18} className="flex-shrink-0" />
        <motion.span
          animate={{ width: fabCollapsed ? 0 : 'auto', opacity: fabCollapsed ? 0 : 1 }}
          transition={{ duration: 0.18 }}
          className="hidden sm:block overflow-hidden whitespace-nowrap"
        >
          Tiket Baru
        </motion.span>
      </motion.button>
    </div>
  );
}
