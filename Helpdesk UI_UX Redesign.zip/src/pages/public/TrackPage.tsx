import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Search, ArrowLeft, ChevronRight, Download, Send, Paperclip, X, ZoomIn } from 'lucide-react';
import StepperTimeline from '../../components/features/StepperTimeline';
import SlaCountdown from '../../components/features/SlaCountdown';
import { StatusBadge, PriorityBadge } from '../../components/ui/Badge';
import { mockTickets, categoryMeta } from '../../data/mock';
import type { Ticket } from '../../data/types';

function LightboxModal({ url, onClose }: { url: string; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4" onClick={onClose}>
      <div className="relative max-w-3xl w-full" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute -top-10 right-0 text-white/70 hover:text-white p-1"><X size={22} /></button>
        <img src={url} alt="Lampiran" className="rounded-[12px] w-full object-contain max-h-[80vh]" />
      </div>
    </div>
  );
}

export default function TrackPage() {
  const [params] = useSearchParams();
  const defaultId = params.get('id') || 'TICK-20240901-0042';
  const [searchId, setSearchId] = useState(defaultId);
  const [searched, setSearched] = useState(true);
  const [ticket, setTicket] = useState<Ticket | null>(
    mockTickets.find((t) => t.id === defaultId) || mockTickets[0]
  );
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  const handleSearch = () => {
    const found = mockTickets.find((t) => t.id === searchId.replace('#', '').trim()) || mockTickets[0];
    setTicket(found);
    setSearched(true);
  };

  const publicMessages = ticket?.messages.filter((m) => !m.isInternal) ?? [];

  const stageTimestamps = ticket ? {
    1: ticket.createdAt,
    2: ticket.stage >= 2 ? ticket.createdAt : undefined,
    3: ticket.stage >= 3 ? ticket.updatedAt : undefined,
    4: ticket.status === 'closed' ? ticket.updatedAt : undefined,
  } as any : {};

  return (
    <div className="min-h-full bg-[#F4F7F9]">
      {lightboxUrl && <LightboxModal url={lightboxUrl} onClose={() => setLightboxUrl(null)} />}

      {/* Header */}
      <header className="sticky top-0 z-20 backdrop-blur-md bg-white/72 border-b border-[#E2E8F0]/60">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 h-14 flex items-center gap-3">
          <Link to="/" className="flex items-center gap-1.5 text-[#64748B] hover:text-[#0D5C75] transition-colors text-[13px] font-medium">
            <ArrowLeft size={15} /> Beranda
          </Link>
          <ChevronRight size={14} className="text-[#CBD5E1]" />
          <span className="text-[13px] font-semibold text-[#0D5C75]">Lacak Tiket</span>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        {/* Search bar */}
        <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm p-6 mb-6">
          <h1 className="text-[22px] font-bold text-[#0F172A] mb-1">Lacak Status Tiket</h1>
          <p className="text-[14px] text-[#64748B] mb-4">Masukkan ID tiket yang Anda terima saat pengajuan</p>
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
              <input
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Contoh: TICK-20240901-0042"
                className="w-full h-11 pl-9 pr-4 rounded-[10px] border border-[#E2E8F0] text-[14px] font-mono text-[#0F172A] placeholder-[#CBD5E1] focus:outline-none focus:ring-2 focus:ring-[#199FB1]/30 focus:border-[#199FB1] transition-all"
              />
            </div>
            <button
              onClick={handleSearch}
              className="h-11 px-5 rounded-[10px] bg-[#0D5C75] text-white text-[14px] font-semibold hover:bg-[#083342] transition-colors flex-shrink-0"
            >
              Cari
            </button>
          </div>
          <p className="text-[12px] text-[#94A3B8] mt-2">
            Atau lihat semua tiket Anda:{' '}
            <Link to="/my-tickets" className="text-[#199FB1] hover:text-[#0D5C75] font-medium">Tiket Saya →</Link>
          </p>
        </div>

        {/* Results */}
        {searched && ticket && (
          <div className="space-y-5">
            {/* Ticket header card */}
            <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm p-5">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-mono text-[12px] text-[#94A3B8]">#{ticket.id}</span>
                    <StatusBadge status={ticket.status} />
                    <PriorityBadge priority={ticket.priority} />
                  </div>
                  <h2 className="text-[18px] font-bold text-[#0F172A]">{ticket.title}</h2>
                  <p className="text-[13px] text-[#64748B] mt-1">
                    {categoryMeta[ticket.category]?.label} · {ticket.reporter.location}
                  </p>
                </div>
                <SlaCountdown slaTarget={ticket.slaTarget} slaStatus={ticket.slaStatus} />
              </div>

              {/* Stepper */}
              <div className="py-5 border-t border-b border-[#F1F5F9] my-4">
                <StepperTimeline
                  currentStage={ticket.stage}
                  timestamps={stageTimestamps}
                  overSla={ticket.slaStatus === 'breached'}
                />
              </div>

              {/* Description */}
              <div>
                <h3 className="text-[13px] font-semibold text-[#64748B] uppercase tracking-wide mb-2">Deskripsi Masalah</h3>
                <p className="text-[14px] text-[#0F172A] leading-relaxed">{ticket.description}</p>
              </div>

              {/* Attachments */}
              {ticket.attachments.length > 0 && (
                <div className="mt-4">
                  <h3 className="text-[13px] font-semibold text-[#64748B] uppercase tracking-wide mb-2">Lampiran</h3>
                  <div className="flex flex-wrap gap-2">
                    {ticket.attachments.map((att) => (
                      <div key={att.id} className="relative group">
                        <img
                          src={att.url}
                          alt={att.name}
                          className="w-24 h-24 rounded-[10px] object-cover border border-[#E2E8F0] cursor-pointer"
                          onClick={() => setLightboxUrl(att.url)}
                        />
                        <div className="absolute inset-0 bg-black/30 rounded-[10px] opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                          <button onClick={() => setLightboxUrl(att.url)} className="text-white">
                            <ZoomIn size={16} />
                          </button>
                          <button className="text-white"><Download size={16} /></button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Conversation thread */}
            <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm overflow-hidden">
              <div className="px-5 py-4 border-b border-[#F1F5F9]">
                <h3 className="text-[15px] font-bold text-[#0F172A]">Percakapan</h3>
              </div>

              <div className="p-5 space-y-5">
                {publicMessages.length === 0 && (
                  <p className="text-[14px] text-[#94A3B8] text-center py-6">Belum ada percakapan</p>
                )}
                {publicMessages.map((msg) => {
                  const ts = new Date(msg.createdAt);
                  const relTime = (() => {
                    const diff = (Date.now() - ts.getTime()) / 60000;
                    if (diff < 60) return `${Math.round(diff)} mnt lalu`;
                    if (diff < 1440) return `${Math.round(diff / 60)} jam lalu`;
                    return ts.toLocaleDateString('id-ID');
                  })();
                  const isStaff = msg.sender.role !== 'Pelapor';
                  return (
                    <div key={msg.id} className={`flex gap-3 ${isStaff ? 'flex-row-reverse' : ''}`}>
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center text-[12px] font-bold text-white flex-shrink-0 ${isStaff ? 'bg-[#199FB1]' : 'bg-[#64748B]'}`}>
                        {msg.sender.avatarInitials}
                      </div>
                      <div className={`flex flex-col ${isStaff ? 'items-end' : 'items-start'} max-w-[80%]`}>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[12px] font-semibold text-[#0F172A]">{msg.sender.name}</span>
                          <span className="text-[11px] text-[#94A3B8]">{relTime}</span>
                        </div>
                        <div
                          className={`px-4 py-3 rounded-[12px] text-[14px] leading-relaxed ${
                            isStaff ? 'bg-[#EAF4F8] text-[#0D5C75] rounded-tr-[4px]' : 'bg-[#F8FAFC] text-[#0F172A] rounded-tl-[4px]'
                          }`}
                        >
                          {msg.content}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Reply box */}
              {ticket.status !== 'closed' ? (
                <div className="px-5 pb-5">
                  <div className="border border-[#E2E8F0] rounded-[12px] overflow-hidden">
                    <textarea
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      placeholder="Kirim balasan atau tambahan informasi..."
                      rows={3}
                      className="w-full p-3 text-[14px] text-[#0F172A] placeholder-[#CBD5E1] resize-none focus:outline-none"
                    />
                    <div className="flex items-center justify-between px-3 py-2 border-t border-[#F1F5F9] bg-[#F8FAFC]">
                      <button className="p-1.5 rounded text-[#94A3B8] hover:text-[#0D5C75] transition-colors">
                        <Paperclip size={15} />
                      </button>
                      <button
                        disabled={!replyText.trim()}
                        onClick={() => setReplyText('')}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-[8px] text-[13px] font-semibold bg-[#0D5C75] text-white hover:bg-[#083342] disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                      >
                        <Send size={13} /> Kirim
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="px-5 pb-5">
                  <div className="p-3 bg-[#F8FAFC] rounded-[10px] border border-[#E2E8F0] text-center">
                    <p className="text-[13px] text-[#64748B]">Tiket ini telah ditutup. Jika masih ada kendala, silakan <Link to="/submit" className="text-[#199FB1] font-semibold hover:underline">ajukan tiket baru</Link>.</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {searched && !ticket && (
          <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm p-12 text-center">
            <Search size={36} className="text-[#CBD5E1] mx-auto mb-4" />
            <h3 className="text-[18px] font-bold text-[#0F172A] mb-2">Tiket tidak ditemukan</h3>
            <p className="text-[14px] text-[#64748B]">ID tiket tidak sesuai. Periksa kembali ID yang Anda masukkan.</p>
          </div>
        )}
      </div>
    </div>
  );
}
