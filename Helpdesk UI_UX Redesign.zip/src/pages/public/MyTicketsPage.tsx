import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ChevronRight, Search, TicketIcon, PlusCircle } from 'lucide-react';
import { StatusBadge, PriorityBadge } from '../../components/ui/Badge';
import { mockTickets, categoryMeta } from '../../data/mock';
import type { TicketStatus } from '../../data/types';

type TabFilter = 'all' | TicketStatus;

const REPORTER_EMAIL = 'reza.f@kampus.ac.id';
const myTickets = mockTickets.filter((t) => t.reporter.email === REPORTER_EMAIL);

export default function MyTicketsPage() {
  const [tab, setTab] = useState<TabFilter>('all');
  const [search, setSearch] = useState('');

  const tabs: { id: TabFilter; label: string }[] = [
    { id: 'all', label: 'Semua' },
    { id: 'open', label: 'Open' },
    { id: 'in_progress', label: 'In Progress' },
    { id: 'waiting', label: 'Menunggu' },
    { id: 'closed', label: 'Selesai' },
  ];

  const tabCounts: Record<TabFilter, number> = {
    all: myTickets.length,
    open: myTickets.filter((t) => t.status === 'open').length,
    in_progress: myTickets.filter((t) => t.status === 'in_progress').length,
    waiting: myTickets.filter((t) => t.status === 'waiting').length,
    closed: myTickets.filter((t) => t.status === 'closed').length,
  };

  const filtered = myTickets.filter((t) => {
    if (tab !== 'all' && t.status !== tab) return false;
    if (search && !t.id.toLowerCase().includes(search.toLowerCase()) && !t.title.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const stageLabels = ['', 'Masuk', 'Triase', 'Pengerjaan', 'Selesai'];

  return (
    <div className="min-h-full bg-[#F4F7F9]">
      {/* Header */}
      <header className="sticky top-0 z-20 backdrop-blur-md bg-white/72 border-b border-[#E2E8F0]/60">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Link to="/" className="flex items-center gap-1.5 text-[#64748B] hover:text-[#0D5C75] transition-colors text-[13px] font-medium">
              <ArrowLeft size={15} /> Beranda
            </Link>
            <ChevronRight size={14} className="text-[#CBD5E1]" />
            <span className="text-[13px] font-semibold text-[#0D5C75]">Tiket Saya</span>
          </div>
          <Link
            to="/submit"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-[8px] bg-[#0D5C75] text-white text-[12px] font-semibold hover:bg-[#083342] transition-colors"
          >
            <PlusCircle size={13} /> Tiket Baru
          </Link>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        {/* User card */}
        <div className="bg-gradient-to-br from-[#0D5C75] to-[#199FB1] rounded-[16px] p-5 mb-6 text-white">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center text-[18px] font-bold flex-shrink-0">
              RF
            </div>
            <div>
              <p className="text-[16px] font-bold">Reza Firmansyah</p>
              <p className="text-[13px] text-white/70">{REPORTER_EMAIL} · NIM 2021310045</p>
            </div>
            <div className="ml-auto text-right">
              <p className="text-[24px] font-bold">{myTickets.length}</p>
              <p className="text-[12px] text-white/70">Total tiket</p>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari berdasarkan ID atau judul..."
            className="w-full h-10 pl-9 pr-4 rounded-[10px] bg-white border border-[#E2E8F0] text-[13px] text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#199FB1]/30 focus:border-[#199FB1] transition-all"
          />
        </div>

        {/* Tabs */}
        <div className="flex gap-1 overflow-x-auto pb-1 mb-4">
          {tabs.map(({ id, label }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-[8px] text-[13px] font-semibold transition-all ${
                tab === id ? 'bg-[#0D5C75] text-white' : 'text-[#64748B] hover:bg-[#F1F5F9]'
              }`}
            >
              {label}
              <span className={`text-[11px] px-1.5 py-0.5 rounded-full ${tab === id ? 'bg-white/20' : 'bg-[#F1F5F9]'}`}>
                {tabCounts[id]}
              </span>
            </button>
          ))}
        </div>

        {/* Ticket list */}
        {filtered.length === 0 ? (
          <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 p-12 text-center">
            <TicketIcon size={36} className="text-[#CBD5E1] mx-auto mb-4" />
            <h3 className="text-[16px] font-bold text-[#0F172A] mb-2">Belum ada tiket</h3>
            <p className="text-[14px] text-[#64748B] mb-5">Tiket pengaduan Anda akan tampil di sini</p>
            <Link
              to="/submit"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-[10px] bg-[#0D5C75] text-white text-[14px] font-semibold hover:bg-[#083342] transition-colors"
            >
              <PlusCircle size={15} /> Ajukan Tiket Baru
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((ticket) => {
              const catMeta = categoryMeta[ticket.category];
              return (
                <Link
                  key={ticket.id}
                  to={`/track?id=${ticket.id}`}
                  className="block bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm p-4 hover:shadow-md hover:border-[#EAF4F8] hover:scale-[1.005] transition-all duration-150"
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-[11px] text-[#94A3B8]">#{ticket.id}</span>
                      <StatusBadge status={ticket.status} />
                      <PriorityBadge priority={ticket.priority} />
                    </div>
                    <span className="text-[11px] text-[#94A3B8] flex-shrink-0">
                      {new Date(ticket.createdAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </span>
                  </div>

                  <h4 className="text-[14px] font-semibold text-[#0F172A] mb-1">{ticket.title}</h4>

                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-[11px] font-medium px-2 py-0.5 rounded-full" style={{ backgroundColor: `${catMeta?.color}15`, color: catMeta?.color }}>
                      {catMeta?.label}
                    </span>
                    <span className="text-[12px] text-[#64748B]">{ticket.reporter.location}</span>
                  </div>

                  {/* Mini progress stepper dots */}
                  <div className="flex items-center gap-1.5">
                    {[1, 2, 3, 4].map((s) => (
                      <div key={s} className="flex items-center gap-1.5">
                        <div
                          className={`w-2 h-2 rounded-full transition-colors ${
                            s < ticket.stage ? 'bg-[#0D5C75]' :
                            s === ticket.stage ? 'bg-[#199FB1] ring-2 ring-[#199FB1]/30' :
                            'bg-[#E2E8F0]'
                          }`}
                        />
                        {s < 4 && <div className={`h-0.5 w-6 ${s < ticket.stage ? 'bg-[#0D5C75]' : 'bg-[#E2E8F0]'}`} />}
                      </div>
                    ))}
                    <span className="text-[11px] text-[#64748B] ml-2">{stageLabels[ticket.stage]}</span>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
