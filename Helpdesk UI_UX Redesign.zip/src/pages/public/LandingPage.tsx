import { Link } from 'react-router-dom';
import {
  Wifi, Monitor, Building2, Cpu, UserCog, HelpCircle,
  ArrowRight, Clock, TrendingUp, CheckCircle2, Star,
  Headphones, ChevronRight, BarChart2, Shield, Zap
} from 'lucide-react';
import { statsData, categoryMeta } from '../../data/mock';

const categoryIcons: Record<string, React.ComponentType<{ size?: number; strokeWidth?: number; color?: string }>> = {
  network: Wifi, sysinfo: Monitor, sarpras: Building2, hardware: Cpu, account: UserCog, general: HelpCircle,
};

const slaPolicy = [
  { level: 'Urgent', time: '≤ 2 jam', color: '#EF4444', bg: '#FEF2F2', desc: 'Sistem down, event mendesak' },
  { level: 'Tinggi', time: '≤ 8 jam', color: '#F58A61', bg: '#FFF7ED', desc: 'Gangguan layanan penting' },
  { level: 'Sedang', time: '≤ 1×24 jam', color: '#F59E0B', bg: '#FFFBEB', desc: 'Kendala fungsional biasa' },
  { level: 'Rendah', time: '≤ 3×24 jam', color: '#10B981', bg: '#ECFDF5', desc: 'Permintaan & perbaikan umum' },
];

export default function LandingPage() {
  const categories = Object.entries(categoryMeta);

  return (
    <div className="min-h-full bg-[#F4F7F9]">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-white/72 border-b border-[#E2E8F0]/60">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-[10px] bg-[#0D5C75] flex items-center justify-center">
              <Headphones size={18} color="white" strokeWidth={2} />
            </div>
            <div>
              <span className="text-[16px] font-bold text-[#0D5C75] leading-tight block">POSO</span>
              <span className="text-[10px] font-semibold text-[#64748B] uppercase tracking-wider">Helpdesk Kampus</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/track"
              className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-[10px] text-[13px] font-semibold text-[#0D5C75] border border-[#0D5C75]/20 hover:bg-[#EAF4F8] transition-all"
            >
              <Clock size={14} /> Lacak Tiket
            </Link>
            <Link
              to="/dashboard"
              className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-[10px] text-[13px] font-semibold text-[#64748B] hover:bg-[#F1F5F9] transition-all"
            >
              Dashboard Operator
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#083342] via-[#0D5C75] to-[#199FB1] text-white">
        {/* Decorative circles */}
        <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white/5 -translate-y-1/2 translate-x-1/3" />
        <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full bg-[#199FB1]/20 translate-y-1/2 -translate-x-1/3" />

        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-16 sm:py-24 relative">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 border border-white/20 text-[12px] font-semibold text-[#BAE6FC] mb-6">
              <div className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
              Layanan aktif 08.00 – 16.00 WIB
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold leading-tight mb-4">
              Laporkan kendala,<br />
              <span className="text-[#F58A61]">kami tindak lanjuti</span><br />
              dengan SLA yang jelas.
            </h1>
            <p className="text-[16px] text-white/70 leading-relaxed mb-8 max-w-xl">
              Sistem pengaduan terpadu kampus — dari gangguan jaringan, kerusakan fasilitas, hingga kendala sistem informasi. Pantau status real-time kapan saja.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Link
                to="/submit"
                className="flex items-center justify-center gap-2 h-12 px-6 rounded-[10px] bg-[#F58A61] text-white text-[15px] font-semibold hover:bg-[#E77448] transition-all shadow-lg hover:shadow-xl"
              >
                Ajukan Tiket Baru <ArrowRight size={16} />
              </Link>
              <Link
                to="/track"
                className="flex items-center justify-center gap-2 h-12 px-6 rounded-[10px] bg-white/10 border border-white/20 text-white text-[15px] font-semibold hover:bg-white/20 transition-all"
              >
                <Clock size={16} /> Lacak Status Tiket
              </Link>
            </div>
          </div>

          {/* Live stats strip */}
          <div className="flex flex-wrap gap-6 mt-12 pt-8 border-t border-white/15">
            {[
              { value: statsData.resolvedThisMonth, label: 'tiket diselesaikan bulan ini', icon: CheckCircle2 },
              { value: `${statsData.avgResponseHours}j`, label: 'rata-rata waktu respons', icon: Zap },
              { value: `${statsData.resolutionRate}%`, label: 'tingkat resolusi', icon: TrendingUp },
            ].map(({ value, label, icon: Icon }) => (
              <div key={label} className="flex items-center gap-3">
                <Icon size={16} className="text-[#F58A61] flex-shrink-0" />
                <div>
                  <span className="text-[22px] font-bold text-white">{value}</span>
                  <span className="text-[13px] text-white/60 ml-2">{label}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Service category grid */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-14">
        <div className="mb-8">
          <h2 className="text-[24px] font-bold text-[#0F172A]">Pilih Bidang Layanan</h2>
          <p className="text-[15px] text-[#64748B] mt-1">Pilih bidang yang sesuai agar tiket Anda diteruskan ke unit yang tepat</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {categories.map(([key, meta]) => {
            const Icon = categoryIcons[key] || HelpCircle;
            return (
              <Link
                key={key}
                to={`/submit?kategori=${key}`}
                className="group bg-white rounded-[16px] border border-[#E2E8F0]/60 p-5 hover:shadow-[0_8px_24px_rgba(15,23,42,0.10)] hover:border-[#EAF4F8] hover:scale-[1.01] transition-all duration-150 flex flex-col gap-3"
              >
                <div className="flex items-start justify-between">
                  <div
                    className="w-12 h-12 rounded-[12px] flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${meta.color}15` }}
                  >
                    <Icon size={22} color={meta.color} strokeWidth={1.75} />
                  </div>
                  <ChevronRight size={16} className="text-[#CBD5E1] group-hover:text-[#199FB1] group-hover:translate-x-0.5 transition-all" />
                </div>
                <div>
                  <h3 className="text-[15px] font-bold text-[#0F172A] group-hover:text-[#0D5C75] transition-colors">{meta.label}</h3>
                  <p className="text-[13px] text-[#64748B] leading-snug mt-1">{meta.description}</p>
                </div>
                <div className="mt-auto pt-2 border-t border-[#F1F5F9]">
                  <span className="text-[12px] font-semibold text-[#199FB1]">Ajukan laporan →</span>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* SLA Policy */}
      <section className="bg-white border-y border-[#E2E8F0]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
          <div className="mb-8 flex items-center gap-3">
            <div className="w-10 h-10 rounded-[10px] bg-[#EAF4F8] flex items-center justify-center">
              <Shield size={18} color="#0D5C75" />
            </div>
            <div>
              <h2 className="text-[20px] font-bold text-[#0F172A]">Kebijakan SLA Layanan</h2>
              <p className="text-[13px] text-[#64748B]">Target waktu respons berdasarkan tingkat prioritas</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {slaPolicy.map((p) => (
              <div
                key={p.level}
                className="rounded-[16px] border p-4"
                style={{ backgroundColor: p.bg, borderColor: `${p.color}30` }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: p.color }} />
                  <span className="text-[13px] font-bold" style={{ color: p.color }}>{p.level}</span>
                </div>
                <p className="text-[22px] font-bold text-[#0F172A] mb-1">{p.time}</p>
                <p className="text-[12px] text-[#64748B]">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Performance metrics */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
        <h2 className="text-[20px] font-bold text-[#0F172A] mb-6">Performa Layanan Bulan Ini</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Total Tiket', value: statsData.resolvedThisMonth + 18, icon: BarChart2, color: '#0D5C75', bg: '#EAF4F8' },
            { label: 'Tingkat Resolusi', value: `${statsData.resolutionRate}%`, icon: CheckCircle2, color: '#10B981', bg: '#ECFDF5' },
            { label: 'Rata-rata Waktu Selesai', value: `${statsData.avgResolutionHours}j`, icon: Clock, color: '#8B5CF6', bg: '#F5F3FF' },
            { label: 'Respons Pertama', value: `${statsData.avgResponseHours}j`, icon: Zap, color: '#F58A61', bg: '#FFF7ED' },
          ].map(({ label, value, icon: Icon, color, bg }) => (
            <div key={label} className="bg-white rounded-[16px] border border-[#E2E8F0]/60 p-5 shadow-[0_2px_8px_rgba(15,23,42,0.06)]">
              <div className="w-10 h-10 rounded-[12px] flex items-center justify-center mb-3" style={{ backgroundColor: bg }}>
                <Icon size={18} color={color} />
              </div>
              <p className="text-[26px] font-bold text-[#0F172A]">{value}</p>
              <p className="text-[12px] text-[#64748B] mt-1">{label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA bottom */}
      <section className="bg-gradient-to-r from-[#083342] to-[#0D5C75] text-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div>
            <h2 className="text-[22px] font-bold mb-1">Ada kendala? Kami siap membantu.</h2>
            <p className="text-white/70 text-[14px]">Ajukan tiket sekarang dan tim kami akan segera menindaklanjuti.</p>
          </div>
          <div className="flex gap-3 flex-shrink-0">
            <Link
              to="/submit"
              className="flex items-center gap-2 h-11 px-6 rounded-[10px] bg-[#F58A61] text-white text-[14px] font-semibold hover:bg-[#E77448] transition-all shadow-md"
            >
              Ajukan Tiket <ArrowRight size={15} />
            </Link>
            <Link
              to="/my-tickets"
              className="flex items-center gap-2 h-11 px-6 rounded-[10px] bg-white/10 border border-white/20 text-white text-[14px] font-semibold hover:bg-white/20 transition-all"
            >
              Tiket Saya
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#E2E8F0] bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-[8px] bg-[#0D5C75] flex items-center justify-center">
              <Headphones size={14} color="white" />
            </div>
            <span className="text-[13px] font-semibold text-[#64748B]">POSO Helpdesk System © 2024</span>
          </div>
          <div className="flex items-center gap-6">
            <Link to="/track" className="text-[13px] text-[#64748B] hover:text-[#0D5C75] transition-colors">Lacak Tiket</Link>
            <Link to="/my-tickets" className="text-[13px] text-[#64748B] hover:text-[#0D5C75] transition-colors">Tiket Saya</Link>
            <Link to="/dashboard" className="text-[13px] text-[#64748B] hover:text-[#0D5C75] transition-colors">Login Operator</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
