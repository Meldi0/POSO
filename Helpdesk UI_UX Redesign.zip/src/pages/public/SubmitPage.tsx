import { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  ArrowLeft, Upload, X, CheckCircle, Copy, Check,
  AlertCircle, Lightbulb, Headphones, Loader2, ChevronRight
} from 'lucide-react';
import { categoryMeta } from '../../data/mock';

type Priority = 'low' | 'medium' | 'high' | 'urgent';
const priorityConfig: Record<Priority, { label: string; desc: string; color: string; bg: string }> = {
  low: { label: 'Rendah', desc: 'Tidak mengganggu aktivitas utama, bisa menunggu', color: '#64748B', bg: '#F8FAFC' },
  medium: { label: 'Sedang', desc: 'Mengganggu sebagian aktivitas, perlu diselesaikan hari ini', color: '#2563EB', bg: '#EFF6FF' },
  high: { label: 'Tinggi', desc: 'Mengganggu aktivitas penting, berdampak pada banyak orang', color: '#C2410C', bg: '#FFF7ED' },
  urgent: { label: 'Urgent', desc: 'Sistem/layanan kritis down, acara mendesak tidak bisa ditunda', color: '#DC2626', bg: '#FEF2F2' },
};

const subCategoryMap: Record<string, string[]> = {
  network: ['WiFi tidak terhubung', 'Kabel LAN rusak', 'VPN bermasalah', 'Internet lambat', 'Port switch bermasalah'],
  sysinfo: ['SIAKAD tidak bisa diakses', 'Error saat login sistem', 'Data tidak tersimpan', 'Portal akademik down', 'Lainnya'],
  sarpras: ['AC rusak/bocor', 'Lampu mati', 'Kebocoran air', 'Kerusakan furnitur', 'Fasilitas toilet', 'Lainnya'],
  hardware: ['Komputer tidak menyala', 'Proyektor rusak', 'Printer bermasalah', 'Monitor rusak', 'UPS bermasalah'],
  account: ['Reset password gagal', 'Aktivasi akun baru', 'Akun terkunci', 'Perubahan hak akses', 'Lainnya'],
  general: ['Pertanyaan umum', 'Saran & masukan', 'Lainnya'],
};

const contextualTips: Partial<Record<string, string>> = {
  network: 'Sudah coba restart router/AP? Cek juga apakah masalah terjadi di semua perangkat. Sertakan screenshot pesan error jika ada.',
  sysinfo: 'Sertakan screenshot error yang muncul dan URL halaman yang bermasalah. Sebutkan browser yang digunakan.',
  hardware: 'Sertakan foto kondisi perangkat. Jika ada nomor aset (stiker), harap cantumkan.',
  account: 'Sertakan NIM/NIP dan email terdaftar di sistem untuk mempercepat proses verifikasi.',
};

interface FormData {
  nama: string; email: string; phone: string; identityNumber: string;
  kategori: string; subKategori: string; prioritas: Priority; lokasi: string; deskripsi: string;
}

const emptyForm: FormData = { nama: '', email: '', phone: '', identityNumber: '', kategori: '', subKategori: '', prioritas: 'medium', lokasi: '', deskripsi: '' };

const TICKET_ID = `TICK-${new Date().toISOString().slice(0,10).replace(/-/g,'')}–0047`;

export default function SubmitPage() {
  const [params] = useSearchParams();
  const [form, setForm] = useState<FormData>({ ...emptyForm, kategori: params.get('kategori') || '' });
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({});
  const [touched, setTouched] = useState<Set<keyof FormData>>(new Set());
  const [files, setFiles] = useState<File[]>([]);
  const [dragActive, setDragActive] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [copied, setCopied] = useState(false);

  const validate = (data: FormData): Partial<Record<keyof FormData, string>> => {
    const e: Partial<Record<keyof FormData, string>> = {};
    if (!data.nama.trim()) e.nama = 'Nama lengkap wajib diisi';
    if (!data.email.trim()) e.email = 'Email wajib diisi';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) e.email = 'Format email tidak valid';
    if (!data.kategori) e.kategori = 'Pilih kategori layanan';
    if (!data.lokasi.trim()) e.lokasi = 'Lokasi wajib diisi';
    if (!data.deskripsi.trim()) e.deskripsi = 'Deskripsi masalah wajib diisi';
    else if (data.deskripsi.trim().length < 20) e.deskripsi = 'Deskripsi terlalu singkat, tambahkan detail lebih lengkap';
    return e;
  };

  const handleChange = (field: keyof FormData, value: string) => {
    setForm((p) => ({ ...p, [field]: value, ...(field === 'kategori' ? { subKategori: '' } : {}) }));
    if (touched.has(field)) {
      const newForm = { ...form, [field]: value };
      const errs = validate(newForm);
      setErrors((prev) => ({ ...prev, [field]: errs[field] }));
    }
  };

  const handleBlur = (field: keyof FormData) => {
    setTouched((p) => new Set([...p, field]));
    const errs = validate(form);
    setErrors((prev) => ({ ...prev, [field]: errs[field] }));
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault(); setDragActive(false);
    const dropped = Array.from(e.dataTransfer.files).slice(0, 5 - files.length);
    setFiles((p) => [...p, ...dropped]);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const added = Array.from(e.target.files).slice(0, 5 - files.length);
    setFiles((p) => [...p, ...added]);
  };

  const handleSubmit = async () => {
    const allTouched = new Set(Object.keys(emptyForm) as (keyof FormData)[]);
    setTouched(allTouched);
    const errs = validate(form);
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 1800));
    setSubmitting(false);
    setSuccess(true);
  };

  const handleCopyId = () => {
    navigator.clipboard.writeText(TICKET_ID);
    setCopied(true); setTimeout(() => setCopied(false), 2000);
  };

  const catMeta = categoryMeta[form.kategori];
  const subs = subCategoryMap[form.kategori] || [];
  const tip = contextualTips[form.kategori];

  const previewReady = form.nama || form.email || form.kategori || form.deskripsi;

  if (success) {
    return (
      <div className="min-h-full bg-[#F4F7F9] flex items-center justify-center p-4">
        <div className="bg-white rounded-[24px] shadow-xl border border-[#E2E8F0] p-8 max-w-md w-full text-center">
          <div className="w-20 h-20 rounded-full bg-[#ECFDF5] flex items-center justify-center mx-auto mb-5">
            <CheckCircle className="text-[#10B981]" size={40} />
          </div>
          <h2 className="text-[24px] font-bold text-[#0F172A] mb-2">Tiket Berhasil Diajukan!</h2>
          <p className="text-[14px] text-[#64748B] mb-6">Konfirmasi telah dikirim ke email Anda. Tim kami akan segera menindaklanjuti sesuai SLA.</p>
          <div className="bg-[#F8FAFC] rounded-[12px] border border-[#E2E8F0] p-4 mb-6">
            <p className="text-[12px] text-[#64748B] mb-1">ID Tiket Anda</p>
            <div className="flex items-center justify-center gap-3">
              <span className="font-mono text-[18px] font-bold text-[#0D5C75]">{TICKET_ID}</span>
              <button
                onClick={handleCopyId}
                className="p-1.5 rounded-[6px] text-[#94A3B8] hover:text-[#0D5C75] hover:bg-[#EAF4F8] transition-all"
                title="Salin ID"
              >
                {copied ? <Check size={16} className="text-[#10B981]" /> : <Copy size={16} />}
              </button>
            </div>
            {copied && <p className="text-[11px] text-[#10B981] mt-1">Tersalin!</p>}
          </div>
          <div className="flex flex-col gap-3">
            <Link
              to={`/track?id=${TICKET_ID}`}
              className="flex items-center justify-center gap-2 h-11 rounded-[10px] bg-[#0D5C75] text-white text-[14px] font-semibold hover:bg-[#083342] transition-colors"
            >
              Lacak Tiket Ini
            </Link>
            <button
              onClick={() => { setSuccess(false); setForm(emptyForm); setFiles([]); setTouched(new Set()); setErrors({}); }}
              className="flex items-center justify-center gap-2 h-11 rounded-[10px] border border-[#E2E8F0] text-[#64748B] text-[14px] font-semibold hover:bg-[#F8FAFC] transition-colors"
            >
              Ajukan Tiket Lain
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-full bg-[#F4F7F9]">
      {/* Header */}
      <header className="sticky top-0 z-20 backdrop-blur-md bg-white/72 border-b border-[#E2E8F0]/60">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center gap-3">
          <Link to="/" className="flex items-center gap-1.5 text-[#64748B] hover:text-[#0D5C75] transition-colors text-[13px] font-medium">
            <ArrowLeft size={15} /> Beranda
          </Link>
          <ChevronRight size={14} className="text-[#CBD5E1]" />
          <span className="text-[13px] font-semibold text-[#0D5C75]">Ajukan Tiket</span>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="mb-6">
          <h1 className="text-[28px] font-bold text-[#0F172A]">Ajukan Laporan Baru</h1>
          <p className="text-[15px] text-[#64748B] mt-1">Isi formulir di bawah ini dengan lengkap agar laporan dapat ditangani segera</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Form */}
          <div className="lg:col-span-3 space-y-5">
            {/* Data Pelapor */}
            <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm p-6">
              <h2 className="text-[16px] font-bold text-[#0F172A] mb-4">Data Pelapor</h2>
              <div className="space-y-4">
                {/* Nama */}
                <div>
                  <label className="block text-[13px] font-semibold text-[#0F172A] mb-1.5">Nama Lengkap <span className="text-red-500">*</span></label>
                  <input
                    value={form.nama}
                    onChange={(e) => handleChange('nama', e.target.value)}
                    onBlur={() => handleBlur('nama')}
                    placeholder="Nama sesuai kartu identitas"
                    className={`w-full h-10 px-3 rounded-[10px] border text-[14px] text-[#0F172A] placeholder-[#CBD5E1] focus:outline-none focus:ring-2 transition-all ${errors.nama && touched.has('nama') ? 'border-red-400 focus:ring-red-200' : 'border-[#E2E8F0] focus:ring-[#199FB1]/30 focus:border-[#199FB1]'}`}
                  />
                  {errors.nama && touched.has('nama') && (
                    <p className="flex items-center gap-1 text-[12px] text-red-500 mt-1"><AlertCircle size={12} />{errors.nama}</p>
                  )}
                </div>
                {/* Email + Identity Number row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[13px] font-semibold text-[#0F172A] mb-1.5">Email <span className="text-red-500">*</span></label>
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) => handleChange('email', e.target.value)}
                      onBlur={() => handleBlur('email')}
                      placeholder="nama@kampus.ac.id"
                      className={`w-full h-10 px-3 rounded-[10px] border text-[14px] text-[#0F172A] placeholder-[#CBD5E1] focus:outline-none focus:ring-2 transition-all ${errors.email && touched.has('email') ? 'border-red-400 focus:ring-red-200' : 'border-[#E2E8F0] focus:ring-[#199FB1]/30 focus:border-[#199FB1]'}`}
                    />
                    {errors.email && touched.has('email') && (
                      <p className="flex items-center gap-1 text-[12px] text-red-500 mt-1"><AlertCircle size={12} />{errors.email}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-[13px] font-semibold text-[#0F172A] mb-1.5">NIM / NIP</label>
                    <input
                      value={form.identityNumber}
                      onChange={(e) => handleChange('identityNumber', e.target.value)}
                      placeholder="Nomor identitas (opsional)"
                      className="w-full h-10 px-3 rounded-[10px] border border-[#E2E8F0] text-[14px] text-[#0F172A] placeholder-[#CBD5E1] focus:outline-none focus:ring-2 focus:ring-[#199FB1]/30 focus:border-[#199FB1] transition-all"
                    />
                  </div>
                </div>
                {/* Phone + Location */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[13px] font-semibold text-[#0F172A] mb-1.5">No. WhatsApp <span className="text-[#94A3B8] font-normal">(opsional)</span></label>
                    <input
                      value={form.phone}
                      onChange={(e) => handleChange('phone', e.target.value)}
                      placeholder="08xxxxxxxxxx"
                      className="w-full h-10 px-3 rounded-[10px] border border-[#E2E8F0] text-[14px] text-[#0F172A] placeholder-[#CBD5E1] focus:outline-none focus:ring-2 focus:ring-[#199FB1]/30 focus:border-[#199FB1] transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-[13px] font-semibold text-[#0F172A] mb-1.5">Lokasi <span className="text-red-500">*</span></label>
                    <input
                      value={form.lokasi}
                      onChange={(e) => handleChange('lokasi', e.target.value)}
                      onBlur={() => handleBlur('lokasi')}
                      placeholder="Gedung / Ruangan"
                      className={`w-full h-10 px-3 rounded-[10px] border text-[14px] text-[#0F172A] placeholder-[#CBD5E1] focus:outline-none focus:ring-2 transition-all ${errors.lokasi && touched.has('lokasi') ? 'border-red-400 focus:ring-red-200' : 'border-[#E2E8F0] focus:ring-[#199FB1]/30 focus:border-[#199FB1]'}`}
                    />
                    {errors.lokasi && touched.has('lokasi') && (
                      <p className="flex items-center gap-1 text-[12px] text-red-500 mt-1"><AlertCircle size={12} />{errors.lokasi}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Detail Laporan */}
            <div className="bg-white rounded-[16px] border border-[#E2E8F0]/60 shadow-sm p-6">
              <h2 className="text-[16px] font-bold text-[#0F172A] mb-4">Detail Laporan</h2>
              <div className="space-y-4">
                {/* Kategori + Sub */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[13px] font-semibold text-[#0F172A] mb-1.5">Kategori Layanan <span className="text-red-500">*</span></label>
                    <select
                      value={form.kategori}
                      onChange={(e) => handleChange('kategori', e.target.value)}
                      onBlur={() => handleBlur('kategori')}
                      className={`w-full h-10 px-3 rounded-[10px] border text-[14px] text-[#0F172A] bg-white focus:outline-none focus:ring-2 transition-all ${errors.kategori && touched.has('kategori') ? 'border-red-400 focus:ring-red-200' : 'border-[#E2E8F0] focus:ring-[#199FB1]/30 focus:border-[#199FB1]'}`}
                    >
                      <option value="">— Pilih Kategori —</option>
                      {Object.entries(categoryMeta).map(([k, m]) => (
                        <option key={k} value={k}>{m.label}</option>
                      ))}
                    </select>
                    {errors.kategori && touched.has('kategori') && (
                      <p className="flex items-center gap-1 text-[12px] text-red-500 mt-1"><AlertCircle size={12} />{errors.kategori}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-[13px] font-semibold text-[#0F172A] mb-1.5">Sub-Kategori</label>
                    <select
                      value={form.subKategori}
                      onChange={(e) => handleChange('subKategori', e.target.value)}
                      disabled={!form.kategori}
                      className="w-full h-10 px-3 rounded-[10px] border border-[#E2E8F0] text-[14px] text-[#0F172A] bg-white focus:outline-none focus:ring-2 focus:ring-[#199FB1]/30 focus:border-[#199FB1] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                    >
                      <option value="">— Pilih Sub-Kategori —</option>
                      {subs.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </div>

                {/* Priority selector */}
                <div>
                  <label className="block text-[13px] font-semibold text-[#0F172A] mb-2">Tingkat Prioritas</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {(Object.entries(priorityConfig) as [Priority, typeof priorityConfig[Priority]][]).map(([key, cfg]) => (
                      <div
                        key={key}
                        onClick={() => handleChange('prioritas', key)}
                        className={`cursor-pointer rounded-[10px] border-2 p-3 transition-all ${form.prioritas === key ? 'border-current shadow-sm' : 'border-[#E2E8F0] hover:border-current/30'}`}
                        style={form.prioritas === key ? { borderColor: cfg.color, backgroundColor: cfg.bg } : {}}
                      >
                        <div className="flex items-center gap-1.5 mb-1">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: cfg.color }} />
                          <span className="text-[12px] font-bold" style={{ color: cfg.color }}>{cfg.label}</span>
                        </div>
                        <p className="text-[11px] text-[#64748B] leading-tight">{cfg.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Contextual tip */}
                {tip && (
                  <div className="flex items-start gap-3 p-3 bg-[#FFFBEB] rounded-[10px] border border-[#FDE68A]">
                    <Lightbulb size={15} className="text-[#D97706] mt-0.5 flex-shrink-0" />
                    <p className="text-[13px] text-[#92400E]"><strong>Tips:</strong> {tip}</p>
                  </div>
                )}

                {/* Description */}
                <div>
                  <label className="block text-[13px] font-semibold text-[#0F172A] mb-1.5">
                    Deskripsi Masalah <span className="text-red-500">*</span>
                    <span className="font-normal text-[#94A3B8] ml-2">{form.deskripsi.length} karakter</span>
                  </label>
                  <textarea
                    value={form.deskripsi}
                    onChange={(e) => handleChange('deskripsi', e.target.value)}
                    onBlur={() => handleBlur('deskripsi')}
                    placeholder="Jelaskan masalah secara detail: kapan terjadi, perangkat yang terlibat, langkah yang sudah dicoba, dampak terhadap aktivitas..."
                    rows={5}
                    className={`w-full px-3 py-2.5 rounded-[10px] border text-[14px] text-[#0F172A] placeholder-[#CBD5E1] resize-none focus:outline-none focus:ring-2 transition-all ${errors.deskripsi && touched.has('deskripsi') ? 'border-red-400 focus:ring-red-200' : 'border-[#E2E8F0] focus:ring-[#199FB1]/30 focus:border-[#199FB1]'}`}
                  />
                  {errors.deskripsi && touched.has('deskripsi') && (
                    <p className="flex items-center gap-1 text-[12px] text-red-500 mt-1"><AlertCircle size={12} />{errors.deskripsi}</p>
                  )}
                </div>

                {/* File upload */}
                <div>
                  <label className="block text-[13px] font-semibold text-[#0F172A] mb-1.5">Lampiran <span className="text-[#94A3B8] font-normal">(maks. 5 file, 10MB/file)</span></label>
                  <div
                    onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
                    onDragLeave={() => setDragActive(false)}
                    onDrop={handleFileDrop}
                    className={`border-2 border-dashed rounded-[12px] p-6 text-center transition-all ${dragActive ? 'border-[#199FB1] bg-[#EAF4F8]' : 'border-[#E2E8F0] hover:border-[#199FB1]/50 hover:bg-[#F8FAFC]'}`}
                  >
                    <Upload size={20} className="text-[#94A3B8] mx-auto mb-2" />
                    <p className="text-[13px] text-[#64748B]">Tarik & lepas file di sini, atau{' '}
                      <label className="text-[#199FB1] font-semibold cursor-pointer hover:underline">
                        klik untuk memilih
                        <input type="file" multiple accept=".jpg,.jpeg,.png,.pdf" onChange={handleFileInput} className="hidden" />
                      </label>
                    </p>
                    <p className="text-[11px] text-[#CBD5E1] mt-1">JPG, PNG, PDF — maks 10MB per file</p>
                  </div>
                  {files.length > 0 && (
                    <div className="mt-2 grid grid-cols-2 gap-2">
                      {files.map((f, i) => (
                        <div key={i} className="flex items-center gap-2 p-2 bg-[#F8FAFC] rounded-[8px] border border-[#E2E8F0]">
                          <div className="w-8 h-8 rounded-[6px] bg-[#EAF4F8] flex items-center justify-center flex-shrink-0 text-[10px] font-bold text-[#0D5C75]">
                            {f.name.split('.').pop()?.toUpperCase()}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-[12px] font-medium text-[#0F172A] truncate">{f.name}</p>
                            <p className="text-[11px] text-[#94A3B8]">{(f.size / 1024 / 1024).toFixed(1)} MB</p>
                          </div>
                          <button onClick={() => setFiles((p) => p.filter((_, j) => j !== i))} className="text-[#CBD5E1] hover:text-red-400 transition-colors">
                            <X size={14} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Submit */}
            <button
              onClick={handleSubmit}
              disabled={submitting}
              className="w-full h-12 flex items-center justify-center gap-2 rounded-[10px] bg-[#0D5C75] text-white text-[15px] font-semibold hover:bg-[#083342] disabled:opacity-60 disabled:cursor-not-allowed transition-all shadow-sm"
            >
              {submitting ? <><Loader2 size={18} className="animate-spin" /> Mengirim laporan...</> : 'Kirim Laporan'}
            </button>
          </div>

          {/* Live Preview Card */}
          <div className="lg:col-span-2">
            <div className="sticky top-20">
              <h3 className="text-[13px] font-semibold text-[#64748B] uppercase tracking-wide mb-3 flex items-center gap-2">
                <Headphones size={14} /> Pratinjau Tiket
              </h3>
              <div className={`bg-white rounded-[16px] border-2 shadow-sm transition-all ${previewReady ? 'border-[#199FB1]/30' : 'border-[#E2E8F0]/60'}`}>
                {!previewReady ? (
                  <div className="p-8 text-center">
                    <div className="w-12 h-12 rounded-full bg-[#F1F5F9] flex items-center justify-center mx-auto mb-3">
                      <Headphones size={20} className="text-[#CBD5E1]" />
                    </div>
                    <p className="text-[13px] text-[#94A3B8]">Pratinjau tiket akan muncul seiring Anda mengisi formulir</p>
                  </div>
                ) : (
                  <div className="p-5">
                    <div className="flex items-center justify-between mb-3">
                      <span className="font-mono text-[12px] text-[#94A3B8]">#TICK–YYYYMMDD–XXXX</span>
                      {catMeta && (
                        <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full" style={{ backgroundColor: `${catMeta.color}15`, color: catMeta.color }}>
                          {catMeta.label}
                        </span>
                      )}
                    </div>
                    {form.subKategori && (
                      <h4 className="text-[15px] font-bold text-[#0F172A] mb-2">{form.subKategori}</h4>
                    )}
                    {form.deskripsi && (
                      <p className="text-[13px] text-[#64748B] line-clamp-3 mb-3">{form.deskripsi}</p>
                    )}
                    <div className="space-y-2 py-3 border-t border-[#F1F5F9]">
                      {form.nama && <div className="flex gap-2 text-[12px]"><span className="text-[#94A3B8] w-16 flex-shrink-0">Pelapor</span><span className="text-[#0F172A] font-medium">{form.nama}</span></div>}
                      {form.lokasi && <div className="flex gap-2 text-[12px]"><span className="text-[#94A3B8] w-16 flex-shrink-0">Lokasi</span><span className="text-[#0F172A] font-medium">{form.lokasi}</span></div>}
                      <div className="flex gap-2 text-[12px]">
                        <span className="text-[#94A3B8] w-16 flex-shrink-0">Prioritas</span>
                        <span className="font-semibold" style={{ color: priorityConfig[form.prioritas].color }}>
                          {priorityConfig[form.prioritas].label}
                        </span>
                      </div>
                    </div>
                    {files.length > 0 && (
                      <p className="text-[12px] text-[#94A3B8] pt-2 border-t border-[#F1F5F9]">{files.length} lampiran</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
