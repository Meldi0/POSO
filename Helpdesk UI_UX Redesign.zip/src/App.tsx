import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { ToastProvider } from './components/ui/Toast';
import DashboardLayout from './components/layout/DashboardLayout';
import LandingPage from './pages/public/LandingPage';
import SubmitPage from './pages/public/SubmitPage';
import TrackPage from './pages/public/TrackPage';
import MyTicketsPage from './pages/public/MyTicketsPage';
import DashboardPage from './pages/dashboard/DashboardPage';
import AdminPage from './pages/admin/AdminPage';

const router = createBrowserRouter([
  { path: '/', element: <LandingPage /> },
  { path: '/submit', element: <SubmitPage /> },
  { path: '/track', element: <TrackPage /> },
  { path: '/my-tickets', element: <MyTicketsPage /> },
  {
    path: '/dashboard',
    element: <DashboardLayout />,
    children: [
      { index: true, element: <DashboardPage /> },
      { path: 'table', element: <DashboardPage /> },
    ],
  },
  {
    path: '/admin',
    element: <DashboardLayout />,
    children: [
      { path: 'users', element: <AdminPage /> },
      { path: 'datasource', element: <AdminPage /> },
      { path: 'settings', element: <AdminPage /> },
      { path: 'reports', element: <AdminPage /> },
    ],
  },
]);

export default function App() {
  return (
    <ToastProvider>
      <RouterProvider router={router} />
    </ToastProvider>
  );
}
