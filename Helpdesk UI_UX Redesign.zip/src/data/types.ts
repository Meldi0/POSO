export type ServiceCategory =
  | 'network'
  | 'sysinfo'
  | 'sarpras'
  | 'hardware'
  | 'account'
  | 'general';

export type Priority = 'low' | 'medium' | 'high' | 'urgent';
export type TicketStatus = 'open' | 'in_progress' | 'waiting' | 'closed';
export type SlaStatus = 'on_track' | 'at_risk' | 'breached';
export type Stage = 1 | 2 | 3 | 4;

export interface Attachment {
  id: string;
  name: string;
  size: number;
  type: string;
  url: string;
}

export interface TechnicianRef {
  id: string;
  name: string;
  unit: string;
  avatarInitials: string;
  activeTickets: number;
}

export interface Message {
  id: string;
  ticketId: string;
  sender: { name: string; role: string; avatarInitials: string };
  content: string;
  isInternal: boolean;
  attachments?: Attachment[];
  createdAt: string;
}

export interface Ticket {
  id: string;
  title: string;
  category: ServiceCategory;
  subCategory: string;
  priority: Priority;
  status: TicketStatus;
  reporter: {
    name: string;
    email: string;
    phone?: string;
    identityNumber?: string;
    location: string;
  };
  description: string;
  attachments: Attachment[];
  assignedUnit?: string;
  assignedTechnician?: TechnicianRef;
  slaTarget: string;
  slaStatus: SlaStatus;
  createdAt: string;
  updatedAt: string;
  stage: Stage;
  messages: Message[];
}

export interface StaffUser {
  id: string;
  name: string;
  email: string;
  role: 'operator' | 'teknisi' | 'admin';
  unit: string;
  active: boolean;
  activeTickets: number;
  avatarInitials: string;
}
