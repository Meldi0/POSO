import { useState, useEffect, useRef, useCallback } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Search, TicketIcon, BarChart3, Users, Settings, Plus,
  ArrowRight, Clock, Database, Hash, Zap
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { mockTickets } from '../../data/mock';
import { StatusBadge } from '../ui/Badge';

interface CommandPaletteProps {
  open: boolean;
  onClose: () => void;
}

const quickActions = [
  { id: 'new-ticket', label: 'Buat Tiket Baru', icon: Plus, description: 'Buka form tiket cepat', category: 'Aksi', to: '/submit' },
  { id: 'kanban', label: 'Dashboard Kanban', icon: TicketIcon, description: 'Lihat papan kanban tiket', category: 'Navigasi', to: '/dashboard' },
  { id: 'reports', label: 'Laporan Bulan Ini', icon: BarChart3, description: 'Lihat analitik September 2024', category: 'Navigasi', to: '/admin/reports' },
  { id: 'users', label: 'Manajemen User', icon: Users, description: 'Kelola operator & teknisi', category: 'Navigasi', to: '/admin/users' },
  { id: 'datasource', label: 'Status Integrasi', icon: Database, description: 'Google Workspace connection', category: 'Navigasi', to: '/admin/datasource' },
  { id: 'settings', label: 'Pengaturan SLA', icon: Settings, description: 'Konfigurasi target SLA', category: 'Navigasi', to: '/admin/settings' },
];

export default function CommandPalette({ open, onClose }: CommandPaletteProps) {
  const [query, setQuery] = useState('');
  const [activeIdx, setActiveIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (open) {
      setQuery('');
      setActiveIdx(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  const matchedTickets = query.length >= 2
    ? mockTickets.filter((t) =>
        t.id.toLowerCase().includes(query.toLowerCase()) ||
        t.title.toLowerCase().includes(query.toLowerCase()) ||
        t.reporter.name.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 5)
    : [];

  const matchedActions = query.length === 0
    ? quickActions
    : quickActions.filter((a) =>
        a.label.toLowerCase().includes(query.toLowerCase()) ||
        a.description.toLowerCase().includes(query.toLowerCase())
      );

  const allResults = [
    ...matchedTickets.map((t) => ({ type: 'ticket' as const, item: t })),
    ...matchedActions.map((a) => ({ type: 'action' as const, item: a })),
  ];

  const handleSelect = useCallback((result: typeof allResults[0]) => {
    if (result.type === 'ticket') {
      navigate(`/track?id=${result.item.id}`);
    } else {
      navigate((result.item as typeof quickActions[0]).to);
    }
    onClose();
  }, [navigate, onClose]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!open) return;
      if (e.key === 'ArrowDown') { e.preventDefault(); setActiveIdx((i) => Math.min(i + 1, allResults.length - 1)); }
      if (e.key === 'ArrowUp') { e.preventDefault(); setActiveIdx((i) => Math.max(i - 1, 0)); }
      if (e.key === 'Enter' && allResults[activeIdx]) handleSelect(allResults[activeIdx]);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, allResults, activeIdx, handleSelect]);

  useEffect(() => { setActiveIdx(0); }, [query]);

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 bg-[#0F172A]/50 backdrop-blur-sm z-50"
            onClick={onClose}
          />

          {/* Panel */}
          <motion.div
            initial={{ opacity: 0, scale: 0.97, y: -12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: -8 }}
            transition={{ duration: 0.18, ease: [0.32, 0.72, 0, 1] }}
            className="fixed top-[15vh] left-1/2 -translate-x-1/2 w-full max-w-[580px] z-50 mx-4"
          >
            <div className="bg-white rounded-[20px] shadow-[0_20px_48px_rgba(15,23,42,0.22)] border border-[#E2E8F0] overflow-hidden">
              {/* Search input */}
              <div className="flex items-center gap-3 px-4 py-4 border-b border-[#E2E8F0]">
                <Search size={18} className="text-[#94A3B8] flex-shrink-0" />
                <input
                  ref={inputRef}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Cari tiket, pelapor, atau navigasi cepat..."
                  className="flex-1 text-[15px] text-[#0F172A] placeholder-[#94A3B8] focus:outline-none bg-transparent"
                />
                <kbd className="hidden sm:flex items-center gap-0.5 px-2 py-1 rounded-[6px] bg-[#F1F5F9] text-[11px] font-semibold text-[#64748B] border border-[#E2E8F0]">
                  Esc
                </kbd>
              </div>

              {/* Results */}
              <div className="max-h-[60vh] overflow-y-auto py-2">
                {allResults.length === 0 && query.length >= 2 && (
                  <div className="px-4 py-8 text-center">
                    <Search size={24} className="text-[#CBD5E1] mx-auto mb-2" />
                    <p className="text-[14px] text-[#94A3B8]">Tidak ada hasil untuk "<strong>{query}</strong>"</p>
                  </div>
                )}

                {matchedTickets.length > 0 && (
                  <div>
                    <p className="px-4 py-2 text-[11px] font-bold text-[#94A3B8] uppercase tracking-widest">Tiket</p>
                    {matchedTickets.map((ticket, i) => {
                      const idx = i;
                      const isActive = activeIdx === idx;
                      return (
                        <button
                          key={ticket.id}
                          onClick={() => handleSelect({ type: 'ticket', item: ticket })}
                          onMouseEnter={() => setActiveIdx(idx)}
                          className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors ${isActive ? 'bg-[#EAF4F8]' : 'hover:bg-[#F8FAFC]'}`}
                        >
                          <div className="w-8 h-8 rounded-[8px] bg-[#F1F5F9] flex items-center justify-center flex-shrink-0">
                            <Hash size={14} className="text-[#64748B]" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-[12px] text-[#94A3B8]">{ticket.id}</span>
                              <StatusBadge status={ticket.status} />
                            </div>
                            <p className="text-[13px] font-medium text-[#0F172A] truncate">{ticket.title}</p>
                            <p className="text-[12px] text-[#64748B]">{ticket.reporter.name} · {ticket.reporter.location.split(' - ')[0]}</p>
                          </div>
                          <ArrowRight size={14} className={`text-[#CBD5E1] flex-shrink-0 transition-colors ${isActive ? 'text-[#199FB1]' : ''}`} />
                        </button>
                      );
                    })}
                  </div>
                )}

                {matchedActions.length > 0 && (
                  <div>
                    <p className="px-4 py-2 text-[11px] font-bold text-[#94A3B8] uppercase tracking-widest">
                      {query.length === 0 ? 'Aksi Cepat' : 'Navigasi'}
                    </p>
                    {matchedActions.map((action, i) => {
                      const idx = matchedTickets.length + i;
                      const isActive = activeIdx === idx;
                      const Icon = action.icon;
                      return (
                        <button
                          key={action.id}
                          onClick={() => handleSelect({ type: 'action', item: action })}
                          onMouseEnter={() => setActiveIdx(idx)}
                          className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors ${isActive ? 'bg-[#EAF4F8]' : 'hover:bg-[#F8FAFC]'}`}
                        >
                          <div
                            className="w-8 h-8 rounded-[8px] flex items-center justify-center flex-shrink-0"
                            style={{ backgroundColor: isActive ? '#EAF4F8' : '#F8FAFC' }}
                          >
                            <Icon size={15} color={isActive ? '#0D5C75' : '#64748B'} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-[13px] font-semibold text-[#0F172A]">{action.label}</p>
                            <p className="text-[12px] text-[#64748B]">{action.description}</p>
                          </div>
                          <div className="flex items-center gap-1 flex-shrink-0">
                            <span className="text-[10px] font-semibold text-[#CBD5E1]">{action.category}</span>
                            <ArrowRight size={13} className={`transition-colors ${isActive ? 'text-[#199FB1]' : 'text-[#CBD5E1]'}`} />
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Footer hint */}
              <div className="flex items-center gap-4 px-4 py-2.5 border-t border-[#F1F5F9] bg-[#F8FAFC]">
                {[
                  { keys: ['↑', '↓'], label: 'navigasi' },
                  { keys: ['↵'], label: 'pilih' },
                  { keys: ['Esc'], label: 'tutup' },
                ].map(({ keys, label }) => (
                  <div key={label} className="flex items-center gap-1.5">
                    <div className="flex items-center gap-1">
                      {keys.map((k) => (
                        <kbd key={k} className="px-1.5 py-0.5 rounded-[4px] bg-white border border-[#E2E8F0] text-[10px] font-bold text-[#64748B] shadow-xs">{k}</kbd>
                      ))}
                    </div>
                    <span className="text-[11px] text-[#94A3B8]">{label}</span>
                  </div>
                ))}
                <div className="ml-auto flex items-center gap-1.5">
                  <Zap size={11} className="text-[#199FB1]" />
                  <span className="text-[11px] text-[#94A3B8]">POSO Command</span>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
