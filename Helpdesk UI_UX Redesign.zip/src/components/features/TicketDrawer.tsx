import { useState, useEffect, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  X, Copy, Check, MessageSquare, GitBranch, Info,
  Lock, Send, Paperclip, ChevronDown, User, MapPin,
  Clock, ExternalLink, AlertTriangle
} from 'lucide-react';
import { StatusBadge, PriorityBadge } from '../ui/Badge';
import SlaCountdown from './SlaCountdown';
import { categoryMeta, technicians } from '../../data/mock';
import type { Ticket, TicketStatus, Message } from '../../data/types';

interface TicketDrawerProps {
  ticket: Ticket | null;
  onClose: () => void;
  onStatusChange: (ticket: Ticket, newStatus: TicketStatus) => void;
}

const validTransitions: Record<TicketStatus, TicketStatus[]> = {
  open: ['in_progress', 'closed'],
  in_progress: ['waiting', 'closed'],
  waiting: ['in_progress', 'closed'],
  closed: [],
};

const statusLabels: Record<TicketStatus, string> = {
  open: 'Open',
  in_progress: 'In Progress',
  waiting: 'Menunggu',
  closed: 'Selesai',
};

function Avatar({ initials, size = 8 }: { initials: string; size?: number }) {
  return (
    <div
      className={`w-${size} h-${size} rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0`}
      style={{ backgroundColor: '#0D5C75' }}
    >
      {initials}
    </div>
  );
}

function MessageBubble({ msg }: { msg: Message }) {
  const isInternal = msg.isInternal;
  const ts = new Date(msg.createdAt);
  const relTime = (() => {
    const diff = (Date.now() - ts.getTime()) / 60000;
    if (diff < 60) return `${Math.round(diff)} mnt lalu`;
    if (diff < 1440) return `${Math.round(diff / 60)} jam lalu`;
    return ts.toLocaleDateString('id-ID');
  })();

  return (
    <div className={`flex gap-3 ${isInternal ? 'pl-2 border-l-2 border-[#D97706]' : ''}`}>
      <Avatar initials={msg.sender.avatarInitials} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-[13px] font-semibold text-[#0F172A]">{msg.sender.name}</span>
          <span className="text-[11px] text-[#94A3B8]">{msg.sender.role}</span>
          {isInternal && (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-[#FEF3C7] text-[#D97706]">
              <Lock size={9} /> Internal
            </span>
          )}
          <span className="text-[11px] text-[#94A3B8] ml-auto flex-shrink-0" title={ts.toLocaleString('id-ID')}>
            {relTime}
          </span>
        </div>
        <div
          className={`text-[14px] leading-relaxed p-3 rounded-[10px] ${isInternal ? 'bg-[#FEF3C7] text-[#92400E]' : 'bg-[#F8FAFC] text-[#0F172A]'}`}
        >
          {msg.content}
          {msg.attachments?.map((att) => (
            <img key={att.id} src={att.url} alt={att.name} className="mt-2 rounded-lg max-h-40 object-cover" />
          ))}
        </div>
      </div>
    </div>
  );
}

export default function TicketDrawer({ ticket, onClose, onStatusChange }: TicketDrawerProps) {
  const [activeTab, setActiveTab] = useState<'diskusi' | 'triase' | 'info'>('diskusi');
  const [isInternal, setIsInternal] = useState(false);
  const [msgText, setMsgText] = useState('');
  const [copied, setCopied] = useState(false);
  const [selectedUnit, setSelectedUnit] = useState('');
  const [selectedTech, setSelectedTech] = useState('');
  const drawerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (ticket) {
      setActiveTab('diskusi');
      setSelectedUnit(ticket.assignedUnit || '');
    }
  }, [ticket]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [onClose]);

  const handleCopy = () => {
    if (!ticket) return;
    navigator.clipboard.writeText(ticket.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const catMeta = ticket ? categoryMeta[ticket.category] : null;
  const nextStatuses = ticket ? validTransitions[ticket.status] : [];

  return (
    <AnimatePresence>
      {ticket && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-[#0F172A]/40 backdrop-blur-[2px] z-40"
            onClick={onClose}
          />

          {/* Drawer */}
          <motion.div
            ref={drawerRef}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.28, ease: [0.32, 0.72, 0, 1] }}
            className="fixed right-0 top-0 bottom-0 z-50 w-full sm:w-[480px] bg-white shadow-[0_20px_48px_rgba(15,23,42,0.18)] flex flex-col"
          >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#E2E8F0] flex-shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <span className="font-mono text-[13px] font-semibold text-[#64748B] flex-shrink-0">
              #{ticket.id}
            </span>
            <button
              onClick={handleCopy}
              className="p-1 rounded text-[#94A3B8] hover:text-[#0D5C75] hover:bg-[#EAF4F8] transition-all"
              title="Salin ID Tiket"
            >
              {copied ? <Check size={14} className="text-[#10B981]" /> : <Copy size={14} />}
            </button>
            <StatusBadge status={ticket.status} />
          </div>
          <div className="flex items-center gap-2">
            {nextStatuses.length > 0 && (
              <div className="relative group">
                <button className="flex items-center gap-1 px-3 py-1.5 rounded-[8px] text-[12px] font-semibold bg-[#EAF4F8] text-[#0D5C75] hover:bg-[#0D5C75] hover:text-white transition-all">
                  Ubah Status <ChevronDown size={12} />
                </button>
                <div className="absolute right-0 top-full mt-1 bg-white rounded-[10px] shadow-md border border-[#E2E8F0] py-1 w-40 z-10 hidden group-hover:block">
                  {nextStatuses.map((s) => (
                    <button
                      key={s}
                      onClick={() => onStatusChange(ticket, s)}
                      className="w-full text-left px-3 py-2 text-[13px] hover:bg-[#EAF4F8] text-[#0F172A] transition-colors"
                    >
                      → {statusLabels[s]}
                    </button>
                  ))}
                </div>
              </div>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-[8px] text-[#94A3B8] hover:text-[#0F172A] hover:bg-[#F1F5F9] transition-all"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Ticket title */}
        <div className="px-5 py-3 border-b border-[#F1F5F9] flex-shrink-0">
          <h2 className="text-[16px] font-semibold text-[#0F172A] leading-snug mb-2">{ticket.title}</h2>
          <div className="flex items-center gap-2 flex-wrap">
            <span
              className="inline-flex items-center gap-1.5 px-2 py-1 rounded-[6px] text-[11px] font-semibold"
              style={{ backgroundColor: `${catMeta?.color}15`, color: catMeta?.color }}
            >
              {catMeta?.label}
            </span>
            <PriorityBadge priority={ticket.priority} />
            <SlaCountdown slaTarget={ticket.slaTarget} slaStatus={ticket.slaStatus} compact />
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-[#E2E8F0] flex-shrink-0 px-5 relative">
          {([
            { id: 'diskusi', label: 'Diskusi', icon: MessageSquare },
            { id: 'triase', label: 'Triase & UPT', icon: GitBranch },
            { id: 'info', label: 'Info & SLA', icon: Info },
          ] as const).map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`relative flex items-center gap-2 px-3 py-3 text-[13px] font-semibold transition-colors duration-150 ${
                activeTab === id ? 'text-[#0D5C75]' : 'text-[#64748B] hover:text-[#0F172A]'
              }`}
            >
              <Icon size={14} />
              {label}
              {activeTab === id && (
                <motion.div
                  layoutId="drawer-tab-indicator"
                  className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#199FB1]"
                  transition={{ duration: 0.2, ease: [0.32, 0.72, 0, 1] }}
                />
              )}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {/* DISKUSI TAB */}
          {activeTab === 'diskusi' && ticket && (
            <div className="flex flex-col h-full">
              <div className="flex-1 p-5 space-y-5 overflow-y-auto">
                {ticket.messages.length === 0 && (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <MessageSquare size={32} className="text-[#CBD5E1] mb-3" />
                    <p className="text-[14px] text-[#94A3B8]">Belum ada pesan</p>
                    <p className="text-[12px] text-[#CBD5E1] mt-1">Mulai percakapan dengan pelapor di bawah</p>
                  </div>
                )}
                {ticket.messages.map((msg) => (
                  <MessageBubble key={msg.id} msg={msg} />
                ))}
              </div>

              {/* Reply box */}
              <div
                className={`flex-shrink-0 border-t p-4 transition-colors duration-200 ${isInternal ? 'bg-[#FFFBEB] border-[#FDE68A]' : 'bg-white border-[#E2E8F0]'}`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <div
                      onClick={() => setIsInternal((p) => !p)}
                      className={`w-8 h-4 rounded-full transition-colors duration-200 relative ${isInternal ? 'bg-[#D97706]' : 'bg-[#E2E8F0]'}`}
                    >
                      <div className={`absolute top-0.5 w-3 h-3 rounded-full bg-white shadow transition-transform duration-200 ${isInternal ? 'left-4' : 'left-0.5'}`} />
                    </div>
                    <span className={`text-[12px] font-semibold ${isInternal ? 'text-[#D97706]' : 'text-[#64748B]'}`}>
                      {isInternal ? '🔒 Catatan Internal (Hanya Staf)' : 'Balas ke Pelapor'}
                    </span>
                  </label>
                </div>
                <textarea
                  value={msgText}
                  onChange={(e) => setMsgText(e.target.value)}
                  placeholder={isInternal ? 'Tulis catatan internal (tidak terlihat oleh pelapor)...' : 'Tulis balasan ke pelapor...'}
                  className={`w-full resize-none rounded-[10px] p-3 text-[14px] border transition-colors duration-200 focus:outline-none focus:ring-2 ${
                    isInternal
                      ? 'bg-[#FEF3C7] border-[#FDE68A] text-[#92400E] placeholder-[#D97706]/50 focus:ring-[#D97706]/30'
                      : 'bg-[#F8FAFC] border-[#E2E8F0] text-[#0F172A] placeholder-[#CBD5E1] focus:ring-[#199FB1]/30'
                  }`}
                  rows={3}
                  onKeyDown={(e) => {
                    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && msgText.trim()) {
                      setMsgText('');
                    }
                  }}
                />
                <div className="flex items-center justify-between mt-2">
                  <button className="p-1.5 rounded-[6px] text-[#94A3B8] hover:text-[#0D5C75] hover:bg-[#EAF4F8] transition-all">
                    <Paperclip size={15} />
                  </button>
                  <button
                    disabled={!msgText.trim()}
                    onClick={() => setMsgText('')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-[8px] text-[13px] font-semibold bg-[#0D5C75] text-white hover:bg-[#083342] disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                  >
                    <Send size={13} /> Kirim
                  </button>
                </div>
                <p className="text-[11px] text-[#94A3B8] mt-1">Ctrl+Enter untuk kirim cepat</p>
              </div>
            </div>
          )}

          {/* TRIASE TAB */}
          {activeTab === 'triase' && (
            <div className="p-5 space-y-5">
              <div>
                <label className="block text-[12px] font-semibold text-[#64748B] mb-2 uppercase tracking-wide">
                  Disposisi ke Unit
                </label>
                <select
                  value={selectedUnit}
                  onChange={(e) => setSelectedUnit(e.target.value)}
                  className="w-full h-10 px-3 rounded-[10px] border border-[#E2E8F0] text-[14px] text-[#0F172A] bg-white focus:outline-none focus:ring-2 focus:ring-[#199FB1]/30 focus:border-[#199FB1]"
                >
                  <option value="">— Pilih Unit —</option>
                  <option value="UPT TI">UPT Teknologi Informasi</option>
                  <option value="UPT Sarpras">UPT Sarana & Prasarana</option>
                  <option value="UPT Humas">UPT Hubungan Masyarakat</option>
                </select>
              </div>

              <div>
                <label className="block text-[12px] font-semibold text-[#64748B] mb-2 uppercase tracking-wide">
                  Assign ke Teknisi
                </label>
                <div className="space-y-2">
                  {technicians.map((tech) => (
                    <div
                      key={tech.id}
                      onClick={() => setSelectedTech(tech.id)}
                      className={`flex items-center gap-3 p-3 rounded-[10px] border cursor-pointer transition-all ${
                        selectedTech === tech.id
                          ? 'border-[#199FB1] bg-[#EAF4F8]'
                          : 'border-[#E2E8F0] hover:border-[#199FB1]/50'
                      }`}
                    >
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                        style={{ backgroundColor: '#0D5C75' }}
                      >
                        {tech.avatarInitials}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[14px] font-semibold text-[#0F172A]">{tech.name}</p>
                        <p className="text-[12px] text-[#64748B]">{tech.unit}</p>
                      </div>
                      <span
                        className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                          tech.activeTickets <= 2 ? 'bg-[#ECFDF5] text-[#059669]' :
                          tech.activeTickets <= 4 ? 'bg-[#FFFBEB] text-[#D97706]' :
                          'bg-[#FEF2F2] text-[#DC2626]'
                        }`}
                      >
                        {tech.activeTickets} tiket aktif
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[12px] font-semibold text-[#64748B] mb-2 uppercase tracking-wide">
                  Ubah Status Tiket
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {nextStatuses.map((s) => (
                    <button
                      key={s}
                      onClick={() => onStatusChange(ticket, s)}
                      className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-[10px] border border-[#E2E8F0] text-[13px] font-semibold text-[#0F172A] hover:border-[#199FB1] hover:bg-[#EAF4F8] hover:text-[#0D5C75] transition-all"
                    >
                      {statusLabels[s]}
                    </button>
                  ))}
                </div>
              </div>

              {/* History Disposisi */}
              <div>
                <label className="block text-[12px] font-semibold text-[#64748B] mb-2 uppercase tracking-wide">
                  Riwayat Disposisi
                </label>
                <div className="space-y-2">
                  <div className="flex items-center gap-3 p-3 bg-[#F8FAFC] rounded-[10px] border border-[#E2E8F0]">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#199FB1] mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-[13px] text-[#0F172A]">Tiket dibuat oleh <strong>Sistem</strong></p>
                      <p className="text-[11px] font-mono text-[#64748B]">{new Date(ticket.createdAt).toLocaleString('id-ID')}</p>
                    </div>
                  </div>
                  {ticket.assignedUnit && (
                    <div className="flex items-center gap-3 p-3 bg-[#F8FAFC] rounded-[10px] border border-[#E2E8F0]">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#10B981] mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="text-[13px] text-[#0F172A]">Didisposisi ke <strong>{ticket.assignedUnit}</strong></p>
                        <p className="text-[11px] font-mono text-[#64748B]">{new Date(ticket.updatedAt).toLocaleString('id-ID')}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <button className="w-full h-10 flex items-center justify-center gap-2 rounded-[10px] bg-[#0D5C75] text-white text-[14px] font-semibold hover:bg-[#083342] transition-colors">
                Simpan Disposisi
              </button>
            </div>
          )}

          {/* INFO TAB */}
          {activeTab === 'info' && (
            <div className="p-5 space-y-5">
              {/* Reporter info */}
              <div className="bg-[#F8FAFC] rounded-[12px] border border-[#E2E8F0] p-4 space-y-3">
                <h3 className="text-[12px] font-semibold text-[#64748B] uppercase tracking-wide flex items-center gap-2">
                  <User size={13} /> Data Pelapor
                </h3>
                <div className="space-y-2">
                  {[
                    { label: 'Nama', value: ticket.reporter.name },
                    { label: 'Email', value: ticket.reporter.email },
                    ticket.reporter.phone ? { label: 'WhatsApp', value: ticket.reporter.phone } : null,
                    ticket.reporter.identityNumber ? { label: 'NIM/NIP', value: ticket.reporter.identityNumber } : null,
                  ].filter(Boolean).map((item) => (
                    <div key={item!.label} className="flex items-start gap-3">
                      <span className="text-[12px] text-[#64748B] w-20 flex-shrink-0">{item!.label}</span>
                      <span className="text-[13px] font-medium text-[#0F172A] break-all">{item!.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Location */}
              <div className="flex items-start gap-3 p-3 bg-[#F8FAFC] rounded-[10px] border border-[#E2E8F0]">
                <MapPin size={15} className="text-[#64748B] mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-[12px] text-[#64748B]">Lokasi</p>
                  <p className="text-[14px] font-medium text-[#0F172A]">{ticket.reporter.location}</p>
                </div>
              </div>

              {/* SLA section */}
              <div className="bg-[#F8FAFC] rounded-[12px] border border-[#E2E8F0] p-4 space-y-3">
                <h3 className="text-[12px] font-semibold text-[#64748B] uppercase tracking-wide flex items-center gap-2">
                  <Clock size={13} /> Status SLA
                </h3>
                <SlaCountdown slaTarget={ticket.slaTarget} slaStatus={ticket.slaStatus} />
                <div className="space-y-2 pt-1">
                  {[
                    { label: 'Dibuat', value: new Date(ticket.createdAt).toLocaleString('id-ID') },
                    { label: 'Diperbarui', value: new Date(ticket.updatedAt).toLocaleString('id-ID') },
                    { label: 'Target SLA', value: new Date(ticket.slaTarget).toLocaleString('id-ID') },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center gap-3">
                      <span className="text-[12px] text-[#64748B] w-24 flex-shrink-0">{item.label}</span>
                      <span className="text-[12px] font-mono text-[#0F172A]">{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* SOP Link */}
              <div className="p-3 bg-[#EAF4F8] rounded-[10px] border border-[#199FB1]/30">
                <div className="flex items-center gap-2">
                  <AlertTriangle size={14} className="text-[#199FB1]" />
                  <span className="text-[13px] font-semibold text-[#0D5C75]">Panduan Penanganan</span>
                  <a href="#" className="ml-auto flex items-center gap-1 text-[12px] text-[#199FB1] hover:text-[#0D5C75] font-medium">
                    Buka SOP <ExternalLink size={11} />
                  </a>
                </div>
                <p className="text-[12px] text-[#64748B] mt-1">
                  SOP untuk kategori: <strong>{categoryMeta[ticket.category]?.label}</strong>
                </p>
              </div>
            </div>
          )}
        </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
