import { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';
import type { SlaStatus } from '../../data/types';

interface SlaCountdownProps {
  slaTarget: string;
  slaStatus: SlaStatus;
  compact?: boolean;
}

function getTimeRemaining(target: string) {
  const diff = new Date(target).getTime() - Date.now();
  const abs = Math.abs(diff);
  const h = Math.floor(abs / 3600000);
  const m = Math.floor((abs % 3600000) / 60000);
  return { diff, h, m, breached: diff < 0 };
}

export default function SlaCountdown({ slaTarget, slaStatus, compact = false }: SlaCountdownProps) {
  const [time, setTime] = useState(() => getTimeRemaining(slaTarget));

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(getTimeRemaining(slaTarget));
    }, 60000);
    return () => clearInterval(interval);
  }, [slaTarget]);

  const colorConfig = {
    on_track: { text: '#059669', bg: '#ECFDF5', border: '#A7F3D0' },
    at_risk: { text: '#D97706', bg: '#FFFBEB', border: '#FDE68A' },
    breached: { text: '#DC2626', bg: '#FEF2F2', border: '#FECACA' },
  };

  const cfg = colorConfig[slaStatus];
  const label = time.breached
    ? `Terlambat ${time.h > 0 ? `${time.h}j ` : ''}${time.m}m`
    : `${time.h > 0 ? `${time.h}j ` : ''}${time.m}m tersisa`;

  if (compact) {
    return (
      <span
        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold ${slaStatus === 'breached' ? 'sla-pulse' : ''}`}
        style={{ backgroundColor: cfg.bg, color: cfg.text, border: `1px solid ${cfg.border}` }}
      >
        <Clock size={10} />
        {label}
      </span>
    );
  }

  return (
    <div
      className={`flex items-center gap-2 px-3 py-2 rounded-[10px] border ${slaStatus === 'breached' ? 'sla-pulse' : ''}`}
      style={{ backgroundColor: cfg.bg, borderColor: cfg.border }}
    >
      <Clock size={14} style={{ color: cfg.text }} />
      <span className="text-[13px] font-semibold font-mono" style={{ color: cfg.text }}>
        {label}
      </span>
    </div>
  );
}
