import { useState } from 'react';
import { Layers, Plus } from 'lucide-react';
import TicketCard from './TicketCard';
import { TicketCardSkeleton } from '../ui/Skeleton';
import type { Ticket, TicketStatus } from '../../data/types';

interface KanbanColumn {
  id: TicketStatus;
  label: string;
  color: string;
  dot: string;
}

const columns: KanbanColumn[] = [
  { id: 'open', label: 'Open', color: '#EFF6FF', dot: '#0284C7' },
  { id: 'in_progress', label: 'In Progress', color: '#F5F3FF', dot: '#8B5CF6' },
  { id: 'waiting', label: 'Menunggu', color: '#FFFBEB', dot: '#F59E0B' },
  { id: 'closed', label: 'Selesai', color: '#ECFDF5', dot: '#10B981' },
];

interface KanbanBoardProps {
  tickets: Ticket[];
  loading?: boolean;
  onTicketClick: (ticket: Ticket) => void;
  onStatusChange: (ticket: Ticket, newStatus: TicketStatus) => void;
}

export default function KanbanBoard({ tickets, loading, onTicketClick, onStatusChange }: KanbanBoardProps) {
  const [dragOver, setDragOver] = useState<TicketStatus | null>(null);
  const [dragTicket, setDragTicket] = useState<string | null>(null);
  const [activeMobileCol, setActiveMobileCol] = useState<TicketStatus>('open');

  const getColTickets = (status: TicketStatus) =>
    tickets.filter((t) => t.status === status);

  const handleDragStart = (ticketId: string) => {
    setDragTicket(ticketId);
  };

  const handleDrop = (status: TicketStatus) => {
    if (!dragTicket) return;
    const ticket = tickets.find((t) => t.id === dragTicket);
    if (ticket && ticket.status !== status) {
      onStatusChange(ticket, status);
    }
    setDragTicket(null);
    setDragOver(null);
  };

  const EmptyColState = ({ status }: { status: TicketStatus }) => (
    <div className="flex flex-col items-center justify-center py-10 text-center">
      <Layers size={28} className="text-[#CBD5E1] mb-3" />
      <p className="text-[13px] font-medium text-[#94A3B8]">Tidak ada tiket</p>
      <p className="text-[12px] text-[#CBD5E1] mt-0.5">di status ini</p>
    </div>
  );

  const ColContent = ({ col }: { col: KanbanColumn }) => {
    const colTickets = getColTickets(col.id);

    return (
      <div className="flex flex-col min-h-0 flex-1">
        {loading ? (
          <div className="space-y-3 p-1">
            {[1, 2].map((i) => <TicketCardSkeleton key={i} />)}
          </div>
        ) : colTickets.length === 0 ? (
          <EmptyColState status={col.id} />
        ) : (
          <div className="space-y-3 overflow-y-auto flex-1 pb-2 pr-1">
            {colTickets.map((ticket) => (
              <div
                key={ticket.id}
                draggable
                onDragStart={() => handleDragStart(ticket.id)}
                onDragEnd={() => { setDragTicket(null); setDragOver(null); }}
              >
                <TicketCard
                  ticket={ticket}
                  onClick={onTicketClick}
                  onStatusChange={onStatusChange}
                  dragging={dragTicket === ticket.id}
                />
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      {/* Mobile: pill switcher */}
      <div className="flex gap-2 overflow-x-auto pb-2 lg:hidden">
        {columns.map((col) => {
          const count = getColTickets(col.id).length;
          const isActive = activeMobileCol === col.id;
          return (
            <button
              key={col.id}
              onClick={() => setActiveMobileCol(col.id)}
              className={`flex-shrink-0 flex items-center gap-2 px-4 py-2 rounded-full text-[13px] font-semibold transition-all ${
                isActive ? 'bg-[#0D5C75] text-white shadow-sm' : 'bg-white text-[#64748B] border border-[#E2E8F0]'
              }`}
            >
              <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: isActive ? '#fff' : col.dot }} />
              {col.label}
              <span className={`text-[11px] px-1.5 py-0.5 rounded-full ${isActive ? 'bg-white/20' : 'bg-[#F1F5F9]'}`}>{count}</span>
            </button>
          );
        })}
      </div>

      {/* Mobile single column */}
      <div className="lg:hidden">
        {columns.filter((c) => c.id === activeMobileCol).map((col) => (
          <div key={col.id} className="space-y-3">
            {getColTickets(col.id).length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <Layers size={32} className="text-[#CBD5E1] mb-3" />
                <p className="text-[14px] font-medium text-[#94A3B8]">Tidak ada tiket di status ini</p>
              </div>
            ) : (
              getColTickets(col.id).map((ticket) => (
                <TicketCard
                  key={ticket.id}
                  ticket={ticket}
                  onClick={onTicketClick}
                  onStatusChange={onStatusChange}
                />
              ))
            )}
          </div>
        ))}
      </div>

      {/* Desktop 4-column grid */}
      <div className="hidden lg:grid grid-cols-4 gap-4 flex-1 min-h-0">
        {columns.map((col) => {
          const count = getColTickets(col.id).length;
          const isOver = dragOver === col.id;

          return (
            <div
              key={col.id}
              className={`flex flex-col min-h-0 rounded-[16px] transition-all duration-150 ${isOver ? 'ring-2 ring-[#199FB1] ring-offset-2' : ''}`}
              style={{ backgroundColor: isOver ? col.color : `${col.color}80` }}
              onDragOver={(e) => { e.preventDefault(); setDragOver(col.id); }}
              onDragLeave={() => setDragOver(null)}
              onDrop={() => handleDrop(col.id)}
            >
              {/* Column header */}
              <div className="flex items-center justify-between px-4 pt-4 pb-3 flex-shrink-0">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: col.dot }} />
                  <span className="text-[14px] font-semibold text-[#0F172A]">{col.label}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className="text-[12px] font-bold px-2 py-0.5 rounded-full"
                    style={{ backgroundColor: `${col.dot}15`, color: col.dot }}
                  >
                    {count}
                  </span>
                  {col.id === 'open' && (
                    <button className="w-6 h-6 flex items-center justify-center rounded-full bg-[#0D5C75]/10 text-[#0D5C75] hover:bg-[#0D5C75] hover:text-white transition-all">
                      <Plus size={13} />
                    </button>
                  )}
                </div>
              </div>

              {/* Scrollable cards area */}
              <div className="flex-1 overflow-y-auto px-3 pb-3 min-h-0 space-y-3">
                {loading ? (
                  <>{[1, 2].map((i) => <TicketCardSkeleton key={i} />)}</>
                ) : count === 0 ? (
                  <div className="flex flex-col items-center justify-center py-10 text-center">
                    <Layers size={24} className="text-[#CBD5E1] mb-2" />
                    <p className="text-[12px] text-[#94A3B8]">Tidak ada tiket</p>
                  </div>
                ) : (
                  getColTickets(col.id).map((ticket) => (
                    <div
                      key={ticket.id}
                      draggable
                      onDragStart={() => handleDragStart(ticket.id)}
                      onDragEnd={() => { setDragTicket(null); setDragOver(null); }}
                    >
                      <TicketCard
                        ticket={ticket}
                        onClick={onTicketClick}
                        onStatusChange={onStatusChange}
                        dragging={dragTicket === ticket.id}
                      />
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}
