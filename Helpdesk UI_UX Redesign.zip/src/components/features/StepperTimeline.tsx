import { Check, FileText, GitBranch, Wrench, CheckCircle } from 'lucide-react';
import type { Stage } from '../../data/types';

const stages = [
  { id: 1, label: 'Laporan Masuk', icon: FileText },
  { id: 2, label: 'Triase & Disposisi', icon: GitBranch },
  { id: 3, label: 'Pengerjaan UPT', icon: Wrench },
  { id: 4, label: 'Selesai', icon: CheckCircle },
];

interface StepperTimelineProps {
  currentStage: Stage;
  timestamps?: Partial<Record<Stage, string>>;
  overSla?: boolean;
}

function formatTime(iso?: string) {
  if (!iso) return null;
  return new Date(iso).toLocaleString('id-ID', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}

export default function StepperTimeline({ currentStage, timestamps, overSla }: StepperTimelineProps) {
  return (
    <div className="relative">
      {/* Connector lines (desktop) */}
      <div className="hidden sm:block absolute top-6 left-6 right-6 h-0.5 bg-[#E2E8F0] -z-0" />

      <div className="grid grid-cols-4 gap-2 relative">
        {stages.map((stage) => {
          const stageNum = stage.id as Stage;
          const isCompleted = stageNum < currentStage;
          const isCurrent = stageNum === currentStage;
          const isUpcoming = stageNum > currentStage;
          const Icon = stage.icon;

          const iconBg = isCompleted
            ? '#0D5C75'
            : isCurrent
            ? '#199FB1'
            : '#E2E8F0';

          const iconColor = isCompleted || isCurrent ? '#FFFFFF' : '#94A3B8';

          return (
            <div key={stage.id} className="flex flex-col items-center gap-2 text-center">
              <div className="relative z-10">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${isCurrent ? 'ring-pulse' : ''} ${overSla && isCurrent ? 'ring-pulse' : ''}`}
                  style={{
                    backgroundColor: overSla && isCurrent ? '#EF4444' : iconBg,
                    boxShadow: isCurrent ? '0 0 0 4px rgba(25,159,177,0.15)' : 'none',
                  }}
                >
                  {isCompleted ? (
                    <Check size={20} color="#FFFFFF" strokeWidth={2.5} />
                  ) : (
                    <Icon size={20} color={iconColor} strokeWidth={1.75} />
                  )}
                </div>
              </div>

              <div>
                <p
                  className="text-[13px] font-semibold leading-tight"
                  style={{ color: isUpcoming ? '#94A3B8' : isCompleted ? '#0D5C75' : '#0F172A' }}
                >
                  {stage.label}
                </p>
                {timestamps?.[stageNum] && (
                  <p className="text-[11px] text-[#64748B] font-mono mt-0.5">
                    {formatTime(timestamps[stageNum])}
                  </p>
                )}
                {isCurrent && !timestamps?.[stageNum] && (
                  <p className="text-[11px] font-semibold mt-0.5" style={{ color: overSla ? '#DC2626' : '#199FB1' }}>
                    {overSla ? 'Terlambat' : 'Sedang berjalan'}
                  </p>
                )}
                {isUpcoming && (
                  <p className="text-[11px] text-[#CBD5E1] mt-0.5">Menunggu</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
