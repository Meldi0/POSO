import { useState } from 'react';
import { ArrowUpDown, ArrowUp, ArrowDown, Eye, UserPlus, ChevronLeft, ChevronRight } from 'lucide-react';
import { StatusBadge, PriorityBadge } from '../ui/Badge';
import SlaCountdown from './SlaCountdown';
import { categoryMeta } from '../../data/mock';
import { TableRowSkeleton } from '../ui/Skeleton';
import type { Ticket, TicketStatus } from '../../data/types';

type SortKey = 'id' | 'priority' | 'createdAt' | 'status' | 'category';
type SortDir = 'asc' | 'desc';

const priorityOrder: Record<string, number> = { urgent: 4, high: 3, medium: 2, low: 1 };

interface TicketTableProps {
  tickets: Ticket[];
  loading?: boolean;
  onTicketClick: (ticket: Ticket) => void;
  onStatusChange: (ticket: Ticket, newStatus: TicketStatus) => void;
}

export default function TicketTable({ tickets, loading, onTicketClick }: TicketTableProps) {
  const [sortKey, setSortKey] = useState<SortKey>('createdAt');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const perPage = 10;

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else { setSortKey(key); setSortDir('asc'); }
  };

  const sorted = [...tickets].sort((a, b) => {
    let val = 0;
    if (sortKey === 'id') val = a.id.localeCompare(b.id);
    else if (sortKey === 'priority') val = priorityOrder[a.priority] - priorityOrder[b.priority];
    else if (sortKey === 'createdAt') val = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    else if (sortKey === 'status') val = a.status.localeCompare(b.status);
    else if (sortKey === 'category') val = a.category.localeCompare(b.category);
    return sortDir === 'asc' ? val : -val;
  });

  const totalPages = Math.ceil(sorted.length / perPage);
  const paged = sorted.slice((page - 1) * perPage, page * perPage);

  const SortIcon = ({ col }: { col: SortKey }) => {
    if (sortKey !== col) return <ArrowUpDown size={12} className="opacity-40" />;
    return sortDir === 'asc' ? <ArrowUp size={12} className="text-[#199FB1]" /> : <ArrowDown size={12} className="text-[#199FB1]" />;
  };

  const toggleAll = () => {
    if (selected.size === paged.length) setSelected(new Set());
    else setSelected(new Set(paged.map((t) => t.id)));
  };

  const toggleRow = (id: string) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelected(next);
  };

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* Bulk action bar */}
      {selected.size > 0 && (
        <div className="flex items-center gap-3 px-4 py-2.5 bg-[#EAF4F8] border-b border-[#199FB1]/20 flex-shrink-0">
          <span className="text-[13px] font-semibold text-[#0D5C75]">{selected.size} tiket dipilih</span>
          <button className="px-3 py-1 rounded-[8px] text-[12px] font-semibold bg-[#0D5C75] text-white hover:bg-[#083342] transition-colors">
            Assign Massal
          </button>
          <button className="px-3 py-1 rounded-[8px] text-[12px] font-semibold bg-[#ECFDF5] text-[#059669] hover:bg-[#059669] hover:text-white transition-colors">
            Tutup Massal
          </button>
          <button
            onClick={() => setSelected(new Set())}
            className="ml-auto text-[12px] text-[#64748B] hover:text-[#0F172A]"
          >
            Batalkan
          </button>
        </div>
      )}

      {/* Table */}
      <div className="flex-1 overflow-auto min-h-0">
        <table className="w-full min-w-[900px]">
          <thead className="sticky top-0 bg-[#F8FAFC] z-10">
            <tr className="border-b border-[#E2E8F0]">
              <th className="w-10 px-4 py-3">
                <input
                  type="checkbox"
                  checked={selected.size === paged.length && paged.length > 0}
                  onChange={toggleAll}
                  className="w-4 h-4 rounded accent-[#0D5C75]"
                />
              </th>
              {[
                { key: 'id' as SortKey, label: 'Ticket ID' },
                { key: 'category' as SortKey, label: 'Kategori' },
                { label: 'Judul', noSort: true },
                { key: 'priority' as SortKey, label: 'Prioritas' },
                { key: 'status' as SortKey, label: 'Status' },
                { label: 'SLA', noSort: true },
                { label: 'Assignee', noSort: true },
              ].map(({ key, label, noSort }) => (
                <th
                  key={label}
                  onClick={!noSort && key ? () => handleSort(key) : undefined}
                  className={`px-4 py-3 text-left text-[12px] font-semibold text-[#64748B] whitespace-nowrap ${!noSort ? 'cursor-pointer hover:text-[#0D5C75] select-none' : ''}`}
                >
                  <div className="flex items-center gap-1.5">
                    {label}
                    {!noSort && key && <SortIcon col={key} />}
                  </div>
                </th>
              ))}
              <th className="px-4 py-3 text-left text-[12px] font-semibold text-[#64748B]">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              [...Array(5)].map((_, i) => <TableRowSkeleton key={i} />)
            ) : paged.length === 0 ? (
              <tr>
                <td colSpan={9} className="py-16 text-center text-[14px] text-[#94A3B8]">
                  Tidak ada tiket yang cocok dengan filter
                </td>
              </tr>
            ) : (
              paged.map((ticket) => {
                const catMeta = categoryMeta[ticket.category];
                const isSelected = selected.has(ticket.id);
                return (
                  <tr
                    key={ticket.id}
                    onClick={() => onTicketClick(ticket)}
                    className={`border-b border-[#E2E8F0] cursor-pointer transition-colors group ${
                      isSelected ? 'bg-[#EAF4F8]' : 'hover:bg-[#EAF4F8]/50'
                    }`}
                  >
                    <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleRow(ticket.id)}
                        className="w-4 h-4 rounded accent-[#0D5C75]"
                      />
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-[12px] text-[#64748B]">{ticket.id}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: catMeta?.color }} />
                        <span className="text-[13px] text-[#0F172A] whitespace-nowrap">{catMeta?.label}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 max-w-[240px]">
                      <p className="text-[13px] text-[#0F172A] font-medium truncate">{ticket.title}</p>
                      <p className="text-[11px] text-[#64748B] truncate">{ticket.reporter.name}</p>
                    </td>
                    <td className="px-4 py-3">
                      <PriorityBadge priority={ticket.priority} />
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={ticket.status} />
                    </td>
                    <td className="px-4 py-3">
                      <SlaCountdown slaTarget={ticket.slaTarget} slaStatus={ticket.slaStatus} compact />
                    </td>
                    <td className="px-4 py-3">
                      {ticket.assignedTechnician ? (
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-[#0D5C75] flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0">
                            {ticket.assignedTechnician.avatarInitials}
                          </div>
                          <span className="text-[12px] text-[#0F172A] truncate max-w-[80px]">{ticket.assignedTechnician.name}</span>
                        </div>
                      ) : (
                        <span className="text-[12px] text-[#CBD5E1] italic">-</span>
                      )}
                    </td>
                    <td className="px-4 py-3 opacity-0 group-hover:opacity-100 transition-opacity" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => onTicketClick(ticket)}
                          className="p-1.5 rounded-[6px] text-[#64748B] hover:text-[#0D5C75] hover:bg-[#EAF4F8] transition-all"
                          title="Lihat Detail"
                        >
                          <Eye size={14} />
                        </button>
                        <button
                          className="p-1.5 rounded-[6px] text-[#64748B] hover:text-[#0D5C75] hover:bg-[#EAF4F8] transition-all"
                          title="Assign"
                        >
                          <UserPlus size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0] flex-shrink-0 bg-white">
        <p className="text-[13px] text-[#64748B]">
          Menampilkan {Math.min((page - 1) * perPage + 1, sorted.length)}–{Math.min(page * perPage, sorted.length)} dari <strong>{sorted.length}</strong> tiket
        </p>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="p-1.5 rounded-[8px] border border-[#E2E8F0] text-[#64748B] hover:bg-[#F1F5F9] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeft size={16} />
          </button>
          {[...Array(totalPages)].map((_, i) => (
            <button
              key={i}
              onClick={() => setPage(i + 1)}
              className={`w-8 h-8 rounded-[8px] text-[13px] font-semibold transition-colors ${
                page === i + 1 ? 'bg-[#0D5C75] text-white' : 'text-[#64748B] hover:bg-[#F1F5F9]'
              }`}
            >
              {i + 1}
            </button>
          ))}
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="p-1.5 rounded-[8px] border border-[#E2E8F0] text-[#64748B] hover:bg-[#F1F5F9] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
