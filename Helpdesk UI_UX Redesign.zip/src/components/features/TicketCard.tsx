import { Clock, ArrowRight, CheckCheck, ChevronRight } from 'lucide-react';
import { StatusBadge, PriorityBadge } from '../ui/Badge';
import SlaCountdown from './SlaCountdown';
import { categoryMeta } from '../../data/mock';
import type { Ticket, TicketStatus } from '../../data/types';

interface TicketCardProps {
  ticket: Ticket;
  onClick: (ticket: Ticket) => void;
  onStatusChange: (ticket: Ticket, newStatus: TicketStatus) => void;
  dragging?: boolean;
}

export default function TicketCard({ ticket, onClick, onStatusChange, dragging }: TicketCardProps) {
  const catMeta = categoryMeta[ticket.category];

  const handleProcess = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (ticket.status === 'open') onStatusChange(ticket, 'in_progress');
    else if (ticket.status === 'in_progress') onStatusChange(ticket, 'waiting');
  };

  const handleClose = (e: React.MouseEvent) => {
    e.stopPropagation();
    onStatusChange(ticket, 'closed');
  };

  return (
    <div
      onClick={() => onClick(ticket)}
      className={`
        bg-white rounded-[16px] p-4 border border-[#E2E8F0]/60 cursor-pointer
        transition-all duration-150 select-none group
        hover:shadow-[0_8px_24px_rgba(15,23,42,0.10)] hover:scale-[1.01] hover:border-[#EAF4F8]
        ${dragging ? 'shadow-xl opacity-70 rotate-1' : 'shadow-[0_2px_8px_rgba(15,23,42,0.06)]'}
      `}
      draggable
    >
      {/* Top row */}
      <div className="flex items-start justify-between gap-2 mb-2.5">
        <div className="flex items-center gap-1.5 flex-1 min-w-0">
          <span
            className="w-2 h-2 rounded-full flex-shrink-0"
            style={{ backgroundColor: catMeta?.color }}
          />
          <span className="text-[11px] font-semibold text-[#64748B] truncate">{catMeta?.label}</span>
        </div>
        <PriorityBadge priority={ticket.priority} />
      </div>

      {/* Title */}
      <h4 className="text-[14px] font-semibold text-[#0F172A] leading-snug line-clamp-2 mb-2.5 group-hover:text-[#0D5C75] transition-colors">
        {ticket.title}
      </h4>

      {/* Reporter */}
      <p className="text-[12px] text-[#64748B] mb-3 truncate">
        {ticket.reporter.name} · {ticket.reporter.location.split(' - ')[0]}
      </p>

      {/* SLA */}
      <div className="mb-3">
        <SlaCountdown slaTarget={ticket.slaTarget} slaStatus={ticket.slaStatus} compact />
      </div>

      {/* Bottom row */}
      <div className="flex items-center justify-between pt-2.5 border-t border-[#F1F5F9]">
        {ticket.assignedTechnician ? (
          <div className="flex items-center gap-1.5">
            <div
              className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0"
              style={{ backgroundColor: '#0D5C75' }}
            >
              {ticket.assignedTechnician.avatarInitials}
            </div>
            <span className="text-[12px] text-[#64748B] truncate max-w-[100px]">{ticket.assignedTechnician.name}</span>
          </div>
        ) : (
          <span className="text-[12px] text-[#CBD5E1] italic">Belum didisposisi</span>
        )}

        <div className="flex items-center gap-1">
          {ticket.status === 'open' && (
            <button
              onClick={handleProcess}
              className="flex items-center gap-1 px-2 py-1 rounded-[6px] text-[11px] font-semibold bg-[#EAF4F8] text-[#0D5C75] hover:bg-[#0D5C75] hover:text-white transition-all duration-150"
            >
              <ArrowRight size={12} />
              Proses
            </button>
          )}
          {ticket.status === 'in_progress' && (
            <button
              onClick={handleClose}
              className="flex items-center gap-1 px-2 py-1 rounded-[6px] text-[11px] font-semibold bg-[#ECFDF5] text-[#059669] hover:bg-[#059669] hover:text-white transition-all duration-150"
            >
              <CheckCheck size={12} />
              Selesai
            </button>
          )}
          <button
            onClick={(e) => { e.stopPropagation(); onClick(ticket); }}
            className="p-1 rounded-[6px] text-[#94A3B8] hover:text-[#0D5C75] hover:bg-[#EAF4F8] transition-all duration-150"
          >
            <ChevronRight size={14} />
          </button>
        </div>
      </div>

      {/* Ticket ID */}
      <p className="text-[10px] text-[#CBD5E1] font-mono mt-2">#{ticket.id}</p>
    </div>
  );
}
