import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, ListFilter, BarChart3, Users, Settings,
  ChevronLeft, ChevronRight, Database, LogOut, Headphones
} from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

const navItems = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/dashboard/table', icon: ListFilter, label: 'Semua Tiket' },
  { to: '/admin/reports', icon: BarChart3, label: 'Laporan' },
  { to: '/admin/users', icon: Users, label: 'Manajemen User' },
  { to: '/admin/datasource', icon: Database, label: 'Integrasi Data' },
  { to: '/admin/settings', icon: Settings, label: 'Pengaturan SLA' },
];

export default function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const location = useLocation();

  return (
    <aside
      className="flex flex-col bg-[#083342] text-white transition-all duration-200 ease-in-out flex-shrink-0 relative z-20"
      style={{ width: collapsed ? 72 : 240 }}
    >
      {/* Logo */}
      <div className="flex items-center h-16 px-4 border-b border-white/10 flex-shrink-0 overflow-hidden">
        <div className="w-8 h-8 rounded-[10px] bg-[#199FB1] flex items-center justify-center flex-shrink-0">
          <Headphones size={16} color="white" strokeWidth={2} />
        </div>
        {!collapsed && (
          <div className="ml-3 overflow-hidden">
            <p className="text-[15px] font-bold text-white leading-tight whitespace-nowrap">POSO</p>
            <p className="text-[10px] text-[#199FB1] font-semibold uppercase tracking-wider whitespace-nowrap">Helpdesk System</p>
          </div>
        )}
      </div>

      {/* Nav items */}
      <nav className="flex-1 py-4 space-y-0.5 overflow-hidden">
        {navItems.map(({ to, icon: Icon, label }) => {
          const isActive = location.pathname === to || location.pathname.startsWith(to + '/');
          return (
            <Link
              key={to}
              to={to}
              title={collapsed ? label : undefined}
              className={`flex items-center gap-3 mx-2 px-3 py-2.5 rounded-[10px] transition-all duration-150 group relative ${
                isActive
                  ? 'bg-[#199FB1] text-white shadow-sm'
                  : 'text-white/60 hover:bg-white/10 hover:text-white'
              }`}
            >
              <Icon size={20} strokeWidth={1.75} className="flex-shrink-0" />
              {!collapsed && (
                <span className="text-[14px] font-medium whitespace-nowrap overflow-hidden">{label}</span>
              )}
              {collapsed && (
                <div className="absolute left-full ml-3 px-2 py-1 bg-[#0D5C75] text-white text-[12px] font-medium rounded-[6px] whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity shadow-md z-50">
                  {label}
                </div>
              )}
            </Link>
          );
        })}
      </nav>

      {/* User profile */}
      <div className="border-t border-white/10 p-3 flex-shrink-0">
        <div className={`flex items-center gap-3 px-2 py-2 rounded-[10px] hover:bg-white/10 transition-colors cursor-pointer overflow-hidden ${collapsed ? 'justify-center' : ''}`}>
          <div className="w-8 h-8 rounded-full bg-[#199FB1] flex items-center justify-center text-[12px] font-bold text-white flex-shrink-0">
            AO
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0 overflow-hidden">
              <p className="text-[13px] font-semibold text-white truncate">Ahmad Operator</p>
              <p className="text-[11px] text-[#199FB1] truncate">Operator · Front Office</p>
            </div>
          )}
          {!collapsed && <LogOut size={15} className="text-white/40 hover:text-white flex-shrink-0" />}
        </div>
      </div>

      {/* Collapse toggle */}
      <button
        onClick={onToggle}
        className="absolute -right-3 top-[72px] w-6 h-6 rounded-full bg-[#083342] border border-white/20 flex items-center justify-center text-white/60 hover:text-white hover:border-white/40 transition-all shadow-sm z-30"
      >
        {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
      </button>
    </aside>
  );
}
