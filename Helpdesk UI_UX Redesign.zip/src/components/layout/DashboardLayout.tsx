import { useState, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import CommandPalette from '../features/CommandPalette';
import { Search, Bell, Menu, X } from 'lucide-react';

export default function DashboardLayout() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [cmdOpen, setCmdOpen] = useState(false);

  // Ctrl+K / Cmd+K global shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setCmdOpen((p) => !p);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const notifications = [
    { id: 1, text: 'Tiket TICK-20240901-0043 belum didisposisi (Urgent)', time: '5 mnt lalu', unread: true },
    { id: 2, text: 'SLA tiket TICK-20240901-0042 hampir habis', time: '15 mnt lalu', unread: true },
    { id: 3, text: 'Budi Santoso menyelesaikan tiket #0029', time: '2 jam lalu', unread: false },
  ];
  const unreadCount = notifications.filter((n) => n.unread).length;

  return (
    <div className="flex h-full bg-[#F4F7F9] overflow-hidden">
      {/* Command Palette */}
      <CommandPalette open={cmdOpen} onClose={() => setCmdOpen(false)} />

      {/* Mobile sidebar overlay */}
      {mobileSidebarOpen && (
        <div
          className="fixed inset-0 bg-[#0F172A]/50 backdrop-blur-sm z-30 lg:hidden"
          onClick={() => setMobileSidebarOpen(false)}
        />
      )}

      {/* Mobile sidebar */}
      <div
        className={`fixed left-0 top-0 bottom-0 z-40 lg:hidden transition-transform duration-200 ${mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <Sidebar collapsed={false} onToggle={() => setMobileSidebarOpen(false)} />
      </div>

      {/* Desktop sidebar */}
      <div className="hidden lg:flex flex-shrink-0">
        <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed((p) => !p)} />
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top header bar */}
        <header className="h-14 flex items-center gap-3 px-4 lg:px-6 border-b border-[#E2E8F0] bg-white/80 backdrop-blur-md flex-shrink-0 sticky top-0 z-20">
          <button
            onClick={() => setMobileSidebarOpen(true)}
            className="lg:hidden p-1.5 rounded-[8px] text-[#64748B] hover:bg-[#F1F5F9] transition-colors"
            aria-label="Buka menu"
          >
            <Menu size={20} />
          </button>

          {/* Search / command palette trigger */}
          <button
            onClick={() => setCmdOpen(true)}
            className="flex-1 max-w-md flex items-center gap-2.5 h-9 pl-3 pr-3 rounded-[10px] bg-[#F8FAFC] border border-[#E2E8F0] text-left hover:border-[#199FB1]/60 hover:bg-[#EAF4F8]/30 transition-all group"
          >
            <Search size={14} className="text-[#94A3B8] group-hover:text-[#199FB1] flex-shrink-0 transition-colors" />
            <span className="flex-1 text-[13px] text-[#94A3B8]">Cari tiket, navigasi…</span>
            <div className="hidden sm:flex items-center gap-0.5">
              <kbd className="px-1.5 py-0.5 rounded-[4px] bg-white border border-[#E2E8F0] text-[10px] font-bold text-[#94A3B8] shadow-xs">⌘</kbd>
              <kbd className="px-1.5 py-0.5 rounded-[4px] bg-white border border-[#E2E8F0] text-[10px] font-bold text-[#94A3B8] shadow-xs">K</kbd>
            </div>
          </button>

          <div className="ml-auto flex items-center gap-2">
            {/* Notifications */}
            <div className="relative">
              <button
                onClick={() => setNotifOpen((p) => !p)}
                className="relative p-2 rounded-[10px] text-[#64748B] hover:bg-[#F1F5F9] hover:text-[#0F172A] transition-all"
                aria-label={`Notifikasi (${unreadCount} belum dibaca)`}
              >
                <Bell size={18} />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-[#EF4444] text-white text-[10px] font-bold flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>

              {notifOpen && (
                <>
                  <div className="fixed inset-0 z-20" onClick={() => setNotifOpen(false)} />
                  <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-[16px] shadow-[0_8px_24px_rgba(15,23,42,0.10)] border border-[#E2E8F0] z-30 overflow-hidden">
                    <div className="px-4 py-3 border-b border-[#E2E8F0] flex items-center justify-between">
                      <span className="text-[14px] font-semibold text-[#0F172A]">Notifikasi</span>
                      <button onClick={() => setNotifOpen(false)} className="text-[#94A3B8] hover:text-[#0F172A] transition-colors">
                        <X size={14} />
                      </button>
                    </div>
                    {notifications.map((n) => (
                      <div
                        key={n.id}
                        className={`px-4 py-3 border-b border-[#F1F5F9] hover:bg-[#F8FAFC] cursor-pointer transition-colors ${n.unread ? 'bg-[#EAF4F8]/30' : ''}`}
                      >
                        <div className="flex items-start gap-2">
                          {n.unread && <div className="w-2 h-2 rounded-full bg-[#199FB1] mt-1.5 flex-shrink-0" />}
                          <p className={`text-[13px] leading-snug flex-1 ${n.unread ? 'text-[#0F172A] font-medium' : 'text-[#64748B] pl-4'}`}>{n.text}</p>
                        </div>
                        <p className={`text-[11px] text-[#94A3B8] mt-1 ${n.unread ? 'ml-4' : 'ml-0'}`}>{n.time}</p>
                      </div>
                    ))}
                    <div className="px-4 py-2.5 text-center">
                      <button className="text-[13px] text-[#199FB1] font-semibold hover:text-[#0D5C75] transition-colors">
                        Lihat semua notifikasi
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* User badge */}
            <div className="flex items-center gap-2 pl-2 border-l border-[#E2E8F0]">
              <div className="w-8 h-8 rounded-full bg-[#0D5C75] flex items-center justify-center text-[12px] font-bold text-white select-none">
                AO
              </div>
              <div className="hidden sm:block">
                <p className="text-[13px] font-semibold text-[#0F172A] leading-tight">Ahmad Operator</p>
                <p className="text-[11px] text-[#64748B]">Operator</p>
              </div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto min-h-0">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
