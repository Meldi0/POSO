import { forwardRef } from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'coral' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  icon?: React.ReactNode;
  iconRight?: React.ReactNode;
}

const variants: Record<string, string> = {
  primary: 'bg-[#0D5C75] text-white hover:bg-[#083342] shadow-sm',
  secondary: 'bg-[#EAF4F8] text-[#0D5C75] hover:bg-[#199FB1] hover:text-white',
  outline: 'border border-[#0D5C75] text-[#0D5C75] hover:bg-[#EAF4F8]',
  ghost: 'text-[#64748B] hover:bg-slate-100 hover:text-[#0F172A]',
  coral: 'bg-[#F58A61] text-white hover:bg-[#E77448] shadow-sm',
  danger: 'bg-[#EF4444] text-white hover:bg-[#DC2626] shadow-sm',
};

const sizes: Record<string, string> = {
  sm: 'h-8 px-3 text-[13px] gap-1.5 rounded-[6px]',
  md: 'h-10 px-4 text-[14px] gap-2 rounded-[10px]',
  lg: 'h-12 px-6 text-[15px] gap-2.5 rounded-[10px]',
};

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'primary', size = 'md', loading, icon, iconRight, children, className = '', disabled, ...props }, ref) => {
    return (
      <button
        ref={ref}
        disabled={disabled || loading}
        className={`
          inline-flex items-center justify-center font-semibold transition-all duration-150
          focus-visible:outline-2 focus-visible:outline-[#199FB1] focus-visible:outline-offset-2
          disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer select-none
          ${variants[variant]}
          ${sizes[size]}
          ${className}
        `}
        {...props}
      >
        {loading ? (
          <svg className="animate-spin w-4 h-4 flex-shrink-0" viewBox="0 0 24 24" fill="none">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
        ) : icon ? (
          <span className="flex-shrink-0 w-4 h-4">{icon}</span>
        ) : null}
        {children && <span>{children}</span>}
        {iconRight && !loading && <span className="flex-shrink-0 w-4 h-4">{iconRight}</span>}
      </button>
    );
  }
);

Button.displayName = 'Button';
export default Button;
