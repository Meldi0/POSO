import type { TicketStatus, Priority, SlaStatus } from '../../data/types';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'status' | 'priority' | 'sla' | 'role';
  status?: TicketStatus;
  priority?: Priority;
  slaStatus?: SlaStatus;
  className?: string;
}

const statusConfig: Record<TicketStatus, { label: string; bg: string; text: string; dot: string }> = {
  open: { label: 'Open', bg: '#EFF6FF', text: '#0284C7', dot: '#0284C7' },
  in_progress: { label: 'In Progress', bg: '#F5F3FF', text: '#8B5CF6', dot: '#8B5CF6' },
  waiting: { label: 'Menunggu', bg: '#FFFBEB', text: '#D97706', dot: '#F59E0B' },
  closed: { label: 'Selesai', bg: '#ECFDF5', text: '#059669', dot: '#10B981' },
};

const priorityConfig: Record<Priority, { label: string; bg: string; text: string; dot: string }> = {
  low: { label: 'Rendah', bg: '#F8FAFC', text: '#64748B', dot: '#94A3B8' },
  medium: { label: 'Sedang', bg: '#EFF6FF', text: '#2563EB', dot: '#3B82F6' },
  high: { label: 'Tinggi', bg: '#FFF7ED', text: '#C2410C', dot: '#F58A61' },
  urgent: { label: 'Urgent', bg: '#FEF2F2', text: '#DC2626', dot: '#EF4444' },
};

export function StatusBadge({ status }: { status: TicketStatus }) {
  const cfg = statusConfig[status];
  return (
    <span
      style={{ backgroundColor: cfg.bg, color: cfg.text }}
      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold leading-none tracking-wide"
    >
      <span
        style={{ backgroundColor: cfg.dot }}
        className="w-1.5 h-1.5 rounded-full flex-shrink-0"
      />
      {cfg.label}
    </span>
  );
}

export function PriorityBadge({ priority }: { priority: Priority }) {
  const cfg = priorityConfig[priority];
  return (
    <span
      style={{ backgroundColor: cfg.bg, color: cfg.text }}
      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold leading-none"
    >
      <span
        style={{ backgroundColor: cfg.dot }}
        className="w-1.5 h-1.5 rounded-full flex-shrink-0"
      />
      {cfg.label}
    </span>
  );
}

export function RoleBadge({ role }: { role: string }) {
  const configs: Record<string, { bg: string; text: string; label: string }> = {
    admin: { bg: '#FDF4FF', text: '#9333EA', label: 'Admin' },
    operator: { bg: '#EFF6FF', text: '#1D4ED8', label: 'Operator' },
    teknisi: { bg: '#F0FDF4', text: '#15803D', label: 'Teknisi' },
  };
  const cfg = configs[role] || configs.operator;
  return (
    <span
      style={{ backgroundColor: cfg.bg, color: cfg.text }}
      className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold"
    >
      {cfg.label}
    </span>
  );
}

export default function Badge({ children, className = '' }: BadgeProps) {
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold bg-accent-tint text-primary ${className}`}>
      {children}
    </span>
  );
}
