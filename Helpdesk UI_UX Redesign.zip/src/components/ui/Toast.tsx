import { useState, useEffect, createContext, useContext, useCallback } from 'react';
import { CheckCircle, AlertCircle, Info, X } from 'lucide-react';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
  duration?: number;
}

interface ToastContextValue {
  toast: (msg: string, type?: Toast['type'], duration?: number) => void;
}

const ToastContext = createContext<ToastContextValue>({ toast: () => {} });

export function useToast() {
  return useContext(ToastContext);
}

function ToastItem({ toast, onRemove }: { toast: Toast; onRemove: (id: string) => void }) {
  const [progress, setProgress] = useState(100);
  const duration = toast.duration ?? (toast.type === 'error' ? 6000 : 4000);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((p) => {
        const next = p - (100 / (duration / 100));
        if (next <= 0) {
          clearInterval(interval);
          onRemove(toast.id);
          return 0;
        }
        return next;
      });
    }, 100);
    return () => clearInterval(interval);
  }, [duration, toast.id, onRemove]);

  const icons = { success: CheckCircle, error: AlertCircle, info: Info };
  const colors = {
    success: { bg: '#F0FDF4', border: '#BBF7D0', icon: '#10B981', text: '#065F46' },
    error: { bg: '#FEF2F2', border: '#FECACA', icon: '#EF4444', text: '#7F1D1D' },
    info: { bg: '#EFF6FF', border: '#BFDBFE', icon: '#3B82F6', text: '#1E3A5F' },
  };
  const cfg = colors[toast.type];
  const Icon = icons[toast.type];

  return (
    <div
      className="toast-enter w-80 rounded-[12px] overflow-hidden shadow-xl border"
      style={{ backgroundColor: cfg.bg, borderColor: cfg.border }}
    >
      <div className="flex items-start gap-3 px-4 py-3">
        <Icon size={18} style={{ color: cfg.icon }} className="flex-shrink-0 mt-0.5" />
        <p className="flex-1 text-[13px] font-medium leading-5" style={{ color: cfg.text }}>
          {toast.message}
        </p>
        <button
          onClick={() => onRemove(toast.id)}
          className="flex-shrink-0 opacity-50 hover:opacity-100 transition-opacity"
          style={{ color: cfg.text }}
        >
          <X size={14} />
        </button>
      </div>
      <div className="h-0.5 bg-slate-200/50 mx-4 mb-2 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-none"
          style={{ width: `${progress}%`, backgroundColor: cfg.icon }}
        />
      </div>
    </div>
  );
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const toast = useCallback((message: string, type: Toast['type'] = 'info', duration?: number) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((prev) => [...prev, { id, message, type, duration }]);
  }, []);

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div
        aria-live="polite"
        aria-atomic="false"
        className="fixed top-4 right-4 z-[9999] flex flex-col gap-3 pointer-events-none"
      >
        {toasts.map((t) => (
          <div key={t.id} className="pointer-events-auto">
            <ToastItem toast={t} onRemove={removeToast} />
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}
